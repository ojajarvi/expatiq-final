/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';

/**
 * Hook to manage device network connectivity state.
 * Emits active synchronisation notifications when connection returns.
 */
export function useNetworkState() {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [lastSyncTime, setLastSyncTime] = useState<string>(() => {
    return localStorage.getItem('expatiq_last_sync_utc') || new Date().toISOString();
  });

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      const nowStr = new Date().toISOString();
      setLastSyncTime(nowStr);
      localStorage.setItem('expatiq_last_sync_utc', nowStr);
    };

    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return {
    isOnline,
    lastSyncTime: new Date(lastSyncTime).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }) + ' UTC'
  };
}
