/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PlaneTakeoff, PlaneLanding, MapPin, Calendar, Clock, Sparkles, Navigation, Plus, Trash2 } from 'lucide-react';
import { TravelLog, SimulationPlan, TaxRule } from '../types';

interface TimeLoggerProps {
  logs: TravelLog[];
  onAddLog: (log: Omit<TravelLog, 'id'>) => void;
  onDeleteLog: (id: string) => void;
  activeCountryCode: string;
  onSetActiveCountryCode: (code: string) => void;
  rules: TaxRule[];
  simulation: SimulationPlan | null;
  onSetSimulation: (sim: SimulationPlan | null) => void;
}

export default function TimeLogger({
  logs,
  onAddLog,
  onDeleteLog,
  activeCountryCode,
  onSetActiveCountryCode,
  rules,
  simulation,
  onSetSimulation,
}: TimeLoggerProps) {
  // Manual logging state
  const [logCountry, setLogCountry] = useState<string>('FI');
  const [entryDate, setEntryDate] = useState<string>('2026-05-10');
  const [exitDate, setExitDate] = useState<string>('2026-05-20');
  const [notes, setNotes] = useState<string>('');
  const [verifiedMethod, setVerifiedMethod] = useState<TravelLog['verifiedMethod']>('Manual');

  // Simulation parameters
  const [simCountry, setSimCountry] = useState<string>('FI');
  const [simDays, setSimDays] = useState<number>(14);
  const [isGPSSearching, setIsGPSSearching] = useState<boolean>(false);

  // Quick preset locations for the simulated GPS scan
  const gpsPresets = [
    { name: 'Monaco Yacht Club', lat: 43.737, lng: 7.426, code: 'MC', country: 'Monaco' },
    { name: 'Dubai Int Airport T3 VIP Lounge', lat: 25.253, lng: 55.364, code: 'AE', country: 'United Arab Emirates' },
    { name: 'Zurich Private Banking Hall', lat: 47.368, lng: 8.541, code: 'CH', country: 'Switzerland' },
    { name: 'Helsinki Vantaa Executive Terminal', lat: 60.317, lng: 24.963, code: 'FI', country: 'Finland' },
    { name: 'Singapore Marina Bay', lat: 1.284, lng: 103.851, code: 'SG', country: 'Singapore' }
  ];

  const handleGPSDetect = () => {
    setIsGPSSearching(true);
    setTimeout(() => {
      // Pick a random luxury hub for the nomad traveler GPS scan
      const randomPreset = gpsPresets[Math.floor(Math.random() * gpsPresets.length)];
      onSetActiveCountryCode(randomPreset.code);
      
      // Auto-populate the log form to make travel entry painless
      setLogCountry(randomPreset.code);
      setVerifiedMethod('GPS');
      setNotes(`Scanned GPS at ${randomPreset.name}`);
      
      setIsGPSSearching(false);
      
      // Automatically record an ongoing log if there's no ongoing interval
      const hasOngoing = logs.some(l => l.exitDate === null);
      if (!hasOngoing) {
        onAddLog({
          countryCode: randomPreset.code,
          countryName: randomPreset.country,
          entryDate: new Date().toISOString().split('T')[0],
          exitDate: null,
          notes: `Automatic border crossing logged via GPS: ${randomPreset.name}`,
          verifiedMethod: 'GPS',
          isSimulated: false
        });
      }
    }, 1500);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetRule = rules.find(r => r.countryCode === logCountry);
    const countryName = targetRule ? targetRule.countryName : logCountry;

    onAddLog({
      countryCode: logCountry,
      countryName,
      entryDate,
      exitDate: exitDate || null,
      notes,
      verifiedMethod,
      isSimulated: false,
    });

    setNotes('');
  };

  const handleSimulateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetRule = rules.find(r => r.countryCode === simCountry);
    const countryName = targetRule ? targetRule.countryName : simCountry;

    onSetSimulation({
      id: Math.random().toString(),
      countryCode: simCountry,
      countryName,
      days: simDays,
      startDate: new Date().toISOString().split('T')[0],
    });
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Precision GPS Automatic tracking device */}
      <div className="bg-[#101216] border border-zinc-800 rounded-xl p-5 relative overflow-hidden">
        <div className="absolute top-0 right-0 h-24 w-24 bg-amber-500/5 blur-xl"></div>
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              GPS Auto-Tracking Scan
            </h3>
            <p className="text-[11px] text-zinc-500">Continuous background presence logger</p>
          </div>
          <button
            onClick={handleGPSDetect}
            disabled={isGPSSearching}
            className={`px-3.5 py-1.5 rounded-md text-[11px] font-mono tracking-wider uppercase border text-zinc-100 transition-all flex items-center gap-1.5 ${
              isGPSSearching 
                ? 'bg-zinc-800 border-zinc-700 text-zinc-400 cursor-not-allowed' 
                : 'bg-zinc-900 border-zinc-800 hover:border-amber-400/80 hover:bg-zinc-800'
            }`}
          >
            <Navigation className={`w-3.5 h-3.5 ${isGPSSearching ? 'animate-spin text-amber-500' : 'text-amber-400'}`} />
            {isGPSSearching ? 'Scanning...' : 'Detect Border'}
          </button>
        </div>

        {/* Selected Active Country Telemetry Widget */}
        <div className="grid grid-cols-2 gap-3 bg-[#08090c] p-3 rounded-lg border border-zinc-900">
          <div className="space-y-0.5">
            <span className="text-[9px] font-mono text-zinc-500 tracking-wider">CURRENT RECORDED JURISDICTION</span>
            <div className="text-sm font-bold text-zinc-100 flex items-center gap-1.5 flex-wrap">
              <MapPin className="w-3.5 h-3.5 text-rose-500" />
              {rules.find(r => r.countryCode === activeCountryCode)?.countryName || activeCountryCode}
            </div>
          </div>
          <div className="space-y-0.5">
            <span className="text-[9px] font-mono text-zinc-500 tracking-wider">TRACKING STATUS</span>
            <div className="text-xs text-emerald-400 font-mono font-semibold flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Ledger verified
            </div>
          </div>
        </div>
      </div>

      {/* Manual Entry Form */}
      <div className="bg-[#0d0e12] border border-zinc-800/80 rounded-xl p-5">
        <h3 className="text-xs uppercase font-mono text-zinc-400 tracking-widest mb-4 flex items-center gap-1.5">
          <Plus className="w-4 h-4 text-amber-500" /> Log Custom Stays
        </h3>
        <form onSubmit={handleManualSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3.5">
            <div>
              <label className="block text-[10px] uppercase tracking-wider text-zinc-500 mb-1">Target Country</label>
              <select
                value={logCountry}
                onChange={(e) => setLogCountry(e.target.value)}
                className="w-full bg-zinc-900/80 border border-zinc-800 rounded-lg p-2.5 text-xs text-zinc-200 focus:outline-none focus:border-amber-400 font-sans"
              >
                {rules.map((rule) => (
                  <option key={rule.id} value={rule.countryCode}>
                    {rule.countryName} ({rule.countryCode})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-wider text-zinc-500 mb-1">Validation Source</label>
              <select
                value={verifiedMethod}
                onChange={(e) => setVerifiedMethod(e.target.value as any)}
                className="w-full bg-zinc-900/80 border border-zinc-800 rounded-lg p-2.5 text-xs text-zinc-200 focus:outline-none focus:border-amber-400 font-sans"
              >
                <option value="Manual">Manual Entry</option>
                <option value="GPS">GPS Geolocation</option>
                <option value="Boarding Pass">Audit Boarding Pass</option>
                <option value="Digital Stamp">Passport Stamp Scan</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3.5">
            <div>
              <label className="block text-[10px] uppercase tracking-wider text-zinc-500 mb-1">Custom Entry Date</label>
              <div className="relative">
                <input
                  type="date"
                  value={entryDate}
                  onChange={(e) => setEntryDate(e.target.value)}
                  className="w-full bg-zinc-900/80 border border-zinc-800 rounded-lg p-2.5 text-xs text-zinc-200 focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-wider text-zinc-500 mb-1">Exit Date (Optional)</label>
              <input
                type="date"
                value={exitDate}
                onChange={(e) => setExitDate(e.target.value)}
                placeholder="Currently present"
                className="w-full bg-zinc-900/80 border border-zinc-800 rounded-lg p-2.5 text-xs text-zinc-200 focus:outline-none focus:border-amber-400 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] uppercase tracking-wider text-zinc-500 mb-1">Private Audit Notes</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Flight AY-122 business travel to Monaco"
              className="w-full bg-zinc-900/80 border border-zinc-800 rounded-lg p-2.5 text-xs text-zinc-200 focus:outline-none focus:border-amber-400 placeholder-zinc-600"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-950 font-medium text-xs tracking-wider uppercase transition-all"
          >
            Record compliance interval
          </button>
        </form>
      </div>

      {/* Travel Planning residency forecaster */}
      <div className="bg-[#0b0e14] border border-zinc-800 rounded-xl p-5 relative overflow-hidden">
        <div className="absolute inset-x-0 bottom-0 top-0 bg-radial from-amber-500/1 to-transparent pointer-events-none"></div>
        <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 text-[9px] uppercase font-mono tracking-widest w-fit mb-2">
          <Sparkles className="w-3 h-3" /> Travel Compliance Planner
        </div>
        <h3 className="text-sm font-semibold text-zinc-200 mb-2">Plan Prospective Journeys</h3>
        <p className="text-xs text-zinc-400 mb-4 leading-relaxed">
          Calculate the impact of future journeys to ensure physical presence limits remain within statutory guidelines.
        </p>

        <form onSubmit={handleSimulateSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[9px] uppercase tracking-wider text-zinc-500 mb-1">Target Country</label>
              <select
                value={simCountry}
                onChange={(e) => setSimCountry(e.target.value)}
                className="w-full bg-zinc-900/80 border border-zinc-850 rounded-lg p-2 text-xs text-zinc-200 focus:outline-none"
              >
                {rules.map((rule) => (
                  <option key={rule.id} value={rule.countryCode}>
                    {rule.countryName}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[9px] uppercase tracking-wider text-zinc-500 mb-1">Stay Duration</label>
              <input
                type="number"
                min="1"
                max="365"
                value={simDays}
                onChange={(e) => setSimDays(parseInt(e.target.value) || 1)}
                className="w-full bg-zinc-900/80 border border-zinc-850 rounded-lg p-2 text-xs text-zinc-200 focus:outline-none font-mono"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 font-bold text-xs font-mono uppercase tracking-wider transition-all border border-amber-500/20 flex items-center justify-center gap-1.5"
          >
            Calculate Presence Safety Days
          </button>
        </form>

        {simulation && (
          <div className="mt-4 p-3 bg-zinc-950 rounded-lg border border-amber-500/10 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-zinc-400 font-sans">Active Travel Plan:</span>
              <span className="font-mono text-amber-400">+{simulation.days} Days in {simulation.countryName}</span>
            </div>
            <button
              onClick={() => onSetSimulation(null)}
              className="text-[10px] text-rose-400 hover:text-rose-300 transition-colors uppercase font-mono tracking-wider block ml-auto"
            >
              Clear Travel Plan
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
