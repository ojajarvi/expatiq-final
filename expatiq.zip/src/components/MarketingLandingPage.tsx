/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  MapPin, 
  ArrowRight, 
  Mail, 
  Check, 
  Star, 
  Lock, 
  Globe, 
  Compass, 
  Cpu, 
  HelpCircle,
  FileCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface MarketingLandingPageProps {
  onEnterSandbox: () => void;
}

export default function MarketingLandingPage({ onEnterSandbox }: MarketingLandingPageProps) {
  const [emailAddress, setEmailAddress] = useState<string>('');
  const [waitlistStatus, setWaitlistStatus] = useState<boolean>(false);

  const handleWaitlistSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailAddress.trim()) return;
    setWaitlistStatus(true);
  };

  const featureCards = [
    {
      title: 'Satellite Geofencing Continuity',
      desc: 'Automatic record-keeping of every international border crossing to a single minute with 99.2% verified precision score.'
    },
    {
      title: 'AI residency Exposure predictive',
      desc: 'Model prospective stays, holiday seasons, or board meetings to spot early warning overlaps before triggering tax exposure.'
    },
    {
      title: 'Monochrome PDF Billing exports',
      desc: 'Export legal, bank-certified reports complete with mathematical day calculations and verifiable signature SHA-256 hashes.'
    }
  ];

  return (
    <div className="bg-[#050608] min-h-screen text-zinc-100 flex flex-col justify-between font-sans relative overflow-hidden">
      {" "}
      {/* Background gradients */}
      <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-amber-500/5 to-transparent pointer-events-none"></div>
      <div className="absolute right-0 top-1/4 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top Banner with direct CTA to skip the waitlist */}
      <div className="bg-amber-500/10 border-b border-amber-500/20 py-2.5 px-4 text-center text-[10px] font-mono uppercase tracking-widest text-amber-400 font-bold flex justify-center items-center gap-2">
        <span>♛ EXCLUSIVE PRIVATE LAUNCH FOR HNWS & FAMILY OFFICES</span>
        <button
          onClick={onEnterSandbox}
          className="bg-amber-500 text-zinc-950 font-extrabold px-2.5 py-0.5 rounded text-[9px] uppercase tracking-wider hover:bg-amber-400 transition-all ml-3"
        >
          Skip Waitlist & Launch App
        </button>
      </div>

      {/* 2. Main Executive Header */}
      <header className="px-6 py-5 flex justify-between items-center border-b border-zinc-950">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-zinc-950 border border-zinc-800 rounded-lg flex items-center justify-center text-[#cca568] font-mono font-bold text-xs tracking-tighter">
            EX
          </div>
          <span className="text-xs font-black uppercase tracking-widest font-sans">
            EXPATIQ
          </span>
        </div>

        <button
          onClick={onEnterSandbox}
          className="text-[10px] font-mono uppercase border border-zinc-800 bg-zinc-950 hover:bg-zinc-900 px-3.5 py-1.5 rounded-md hover:text-amber-400 transition-colors font-bold"
        >
          ENTER SECURITY DEMO
        </button>
      </header>

      {/* 3. HERO UNIT SECTIONS */}
      <main className="max-w-4xl mx-auto px-6 py-12 md:py-20 text-center space-y-12">
        <div className="space-y-4">
          <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-zinc-900 border border-zinc-805 text-zinc-400 text-[10px] uppercase font-mono tracking-widest w-fit mx-auto">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-500" /> Dynamic Jurisdiction Intelligence
          </div>
          
          <h1 className="text-4xl md:text-5xl font-black tracking-tight uppercase leading-none max-w-2xl mx-auto font-sans bg-gradient-to-r from-zinc-100 via-white to-zinc-400 bg-clip-text text-transparent">
            Know where you stand.
          </h1>
          <p className="text-sm md:text-base text-zinc-400 max-w-lg mx-auto font-serif italic leading-relaxed">
            "Track your physical presence before it becomes a structural problem." Premium automated residency mapping for internationally mobile executives, venture partners, and wealth managers.
          </p>
        </div>

        {/* 4. WAITLIST HERO SIGNUP */}
        <div className="max-w-md mx-auto p-5 bg-gradient-to-r from-zinc-950 via-[#0a0b0e] to-zinc-950 border border-zinc-900 rounded-2xl space-y-4 shadow-2xl relative">
          <div className="absolute right-0 top-0 w-1/4 h-1/4 bg-amber-500/5 blur-xl"></div>
          
          <span className="text-[9px] font-mono text-zinc-550 block uppercase tracking-wider font-bold">
            Private Waitlist Registration
          </span>

          <AnimatePresence>
            {!waitlistStatus ? (
              <motion.form 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                onSubmit={handleWaitlistSubmit}
                className="space-y-3 text-xs text-left"
              >
                <div>
                  <label className="block text-[9px] uppercase tracking-wider text-zinc-550 mb-1">Corporate or Private Email</label>
                  <div className="flex gap-2">
                    <input
                      type="email"
                      required
                      placeholder="e.g. founder@sovereign-holdings.mc"
                      value={emailAddress}
                      onChange={(e) => setEmailAddress(e.target.value)}
                      className="flex-1 bg-zinc-900 border border-zinc-850 rounded-lg p-2.5 text-zinc-200 focus:outline-none focus:border-amber-500"
                    />
                    <button
                      type="submit"
                      className="px-4 bg-zinc-100 hover:bg-amber-500 hover:text-zinc-950 text-zinc-950 uppercase text-[10px] tracking-wider rounded-lg font-bold transition-all"
                    >
                      Join Waitlist
                    </button>
                  </div>
                </div>
                <p className="text-[9px] text-zinc-650 leading-relaxed font-mono uppercase">
                  ✓ INVITE 3 FRIENDS → SKIP WAITLIST IMMEDIATELY. YOUR DATA IS NEVER SOLD.
                </p>
              </motion.form>
            ) : (
              <motion.div 
                initial={{ scale: 0.95 }}
                animate={{ scale: 1 }}
                className="space-y-2 text-center py-4 bg-emerald-500/10 border border-emerald-500/25 rounded-md"
              >
                <Check className="w-6 h-6 text-emerald-400 mx-auto" />
                <h4 className="text-xs font-bold text-zinc-200 uppercase">Waitlist Spot Secured!</h4>
                <p className="text-[10px] text-zinc-400 max-w-xs mx-auto leading-normal">
                  Your corporate ticket is queued. Share this unique invite code to bypass the queue: <strong>GLOBAL_VIP_WAITLIST</strong>
                </p>
                <button
                  type="button"
                  onClick={onEnterSandbox}
                  className="mt-2 py-1.5 px-3 bg-zinc-100 hover:bg-zinc-200 text-zinc-950 text-[10px] font-mono uppercase font-black tracking-widest rounded"
                >
                  Skip Waitlist Demo Sandbox
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* 5. SEAMLESS FEATURES OVERVIEW GRID */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-left">
          {featureCards.map((feat, i) => (
            <div key={i} className="p-4 bg-zinc-950 border border-zinc-905 rounded-xl h-36 flex flex-col justify-between">
              <span className="text-[10px] font-mono text-amber-500 uppercase tracking-widest font-extrabold pb-1">
                0{i + 1}
              </span>
              <div>
                <h3 className="text-xs font-bold uppercase text-zinc-200 tracking-wider">
                  {feat.title}
                </h3>
                <p className="text-[10.5px] text-zinc-500 leading-snug mt-1">
                  {feat.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* 6. IMMERSIVE PRODUCT PREIVEWS */}
        <div className="p-6 bg-zinc-950 border border-zinc-900 rounded-2xl space-y-4 text-left">
          <div className="flex justify-between items-center border-b border-zinc-900 pb-2.5">
            <span className="text-[10px] font-mono text-zinc-550 uppercase font-bold">EXPATIQ Residency Suite v4.5</span>
            <span className="text-[9px] font-mono text-amber-400">● SIMULATION SANDBOX ACTIVE</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            <div className="p-3 bg-[#06070a] border border-zinc-905 rounded-xl space-y-1.5">
              <span className="text-[9px] text-zinc-550 font-bold uppercase block">COMPLIANCE RISK INDEX</span>
              <div className="flex justify-between border-b border-zinc-900 pb-1">
                <span>Monaco Residency check</span>
                <span className="text-emerald-400 font-bold">92 days / 90d met</span>
              </div>
              <div className="flex justify-between border-b border-zinc-900 pb-1">
                <span>Finland exposure limit</span>
                <span className="text-amber-400 font-bold">165 days / 183d warning</span>
              </div>
              <div className="flex justify-between">
                <span>United Kingdom ties index</span>
                <span className="text-zinc-400 font-bold">28 days / 90d max comfort</span>
              </div>
            </div>

            <div className="p-3 bg-[#06070a] border border-zinc-905 rounded-xl flex flex-col justify-between h-24">
              <div>
                <span className="text-[9px] text-zinc-550 font-bold uppercase block">SYSTEM DISCLAIMER LEVEL 2</span>
                <p className="text-[9px] text-zinc-550 leading-tight block mt-1">
                  NOT INTENDED FOR ILLEGAL TRANSACTING OR JURISDICTION EVASIONS. STRICT LAW AND CERTIFIED ADVISEMENTS REQUIRED FROM REGISTERED FIRMS.
                </p>
              </div>
              <button
                onClick={onEnterSandbox}
                className="text-[9.5px] text-amber-500 font-bold uppercase hover:text-amber-400 transition-colors flex items-center gap-1 mt-1.5"
              >
                Access Active Simulator Sandbox <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* 7. REVOLUT ULTRA STYLE FAQ CONTAINER */}
        <div className="space-y-4 pt-6 text-left max-w-2xl mx-auto">
          <h2 className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-widest text-center border-b border-zinc-900 pb-2">
            Frequently Asked Disclosures
          </h2>

          <div className="space-y-4">
            {[
              {
                q: "Is EXPATIQ designed as a tax advising platform?",
                a: "Absolutely not. EXPATIQ is a premium, high-resolution global residency intelligence and travel documentation assistant designed for internationally mobile sovereigns. It facilitates bulletproof verification records of days spent across international jurisdictions."
              },
              {
                q: "How does the background continuity tracking guard battery?",
                a: "Our adaptive engine is passive. It restricts high-precision queries strictly inside key warning zones (ports, executive airports, borders) and shifts to ultra-low resource cell tower triangulation when presence is stationary in residence."
              },
              {
                q: "How secure is my sovereign flight and GPS timeline history?",
                a: "Data is secured on your device locally with military-grade zero-knowledge logs. Export features are strictly client-controlled, allowing you to generate certified travel documentation solely at your command."
              }
            ].map((faq, fIdx) => (
              <div key={fIdx} className="space-y-1">
                <h4 className="text-xs font-bold text-zinc-200 font-serif">
                  Q: {faq.q}
                </h4>
                <p className="text-[11.5px] text-zinc-500 leading-relaxed font-sans">
                  {faq.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* 8. Minimalist centurion footer */}
      <footer className="px-6 py-10 mt-12 bg-zinc-950 border-t border-zinc-950 text-center text-[9px] text-zinc-650 space-y-2">
        <p className="font-mono uppercase tracking-widest text-[#cca568]">
          EXPATIQ INTEGRATED SECURITIES GROUP • PORT 3000 NOMINAL
        </p>
        <p className="max-w-md mx-auto">
          Not legal, accounting, tax, or investment advice. Always seek local certified public accountant opinions in each monitored jurisdiction. All actions verified via cryptographic signature hash channels.
        </p>
      </footer>
    </div>
  );
}
