/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Globe } from 'lucide-react';
import { TaxRule } from '../types';

interface WorldMapProps {
  daysSummary: Record<string, number>;
  rules: TaxRule[];
  onSelectCountryCode: (code: string) => void;
  activeCountryCode: string;
}

interface HubNode {
  code: string;
  name: string;
  flag: string;
  x: number; // Geographically centered SVG coordinates (viewBox 0 0 800 500)
  y: number;
  desc: string;
}

interface TravelRoute {
  id: string;
  from: string;
  to: string;
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
  controlYOffset: number;
}

export default function WorldMap({ daysSummary, rules, onSelectCountryCode, activeCountryCode }: WorldMapProps) {
  const [hoveredHub, setHoveredHub] = useState<HubNode | null>(null);
  const [pulse, setPulse] = useState<boolean>(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setPulse(prev => !prev);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  // Recalibrated geographic coordinates matching the real world map projection vector paths perfectly
  const hubs: HubNode[] = [
    { code: 'FI', name: 'Finland', flag: '🇫🇮', x: 440, y: 110, desc: 'Schengen border presence tracker' },
    { code: 'MC', name: 'Monaco', flag: '🇲🇨', x: 338, y: 265, desc: 'Primary residency and global tax base' },
    { code: 'CH', name: 'Switzerland', flag: '🇨🇭', x: 345, y: 245, desc: 'Alps compliance threshold log' },
    { code: 'AE', name: 'United Arab Emirates', flag: '🇦🇪', x: 645, y: 410, desc: 'GCC golden visa compliance ledger' },
    { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', x: 295, y: 135, desc: 'Statutory Residence Test (SRT) log' },
    { code: 'PT', name: 'Portugal', flag: '🇵🇹', x: 232, y: 342, desc: 'NHR tax regime stay check' },
    { code: 'ES', name: 'Spain', flag: '🇪🇸', x: 265, y: 348, desc: 'Beckham Law presence checker' }
  ];

  // Elegant luxury aviation routes from Monaco (Main residency base)
  const routes: TravelRoute[] = [
    { id: 'route-monaco-finland', from: 'MC', to: 'FI', fromX: 341, fromY: 262, toX: 440, toY: 110, controlYOffset: 55 },
    { id: 'route-monaco-uae', from: 'MC', to: 'AE', fromX: 342, fromY: 267, toX: 645, toY: 410, controlYOffset: -65 },
    { id: 'route-monaco-uk', from: 'MC', to: 'GB', fromX: 335, fromY: 263, toX: 295, toY: 135, controlYOffset: 45 },
    { id: 'route-monaco-switzerland', from: 'MC', to: 'CH', fromX: 338, fromY: 261, toX: 345, toY: 245, controlYOffset: -12 },
    { id: 'route-monaco-spain', from: 'MC', to: 'ES', fromX: 334, fromY: 268, toX: 265, toY: 348, controlYOffset: -25 },
    { id: 'route-monaco-portugal', from: 'MC', to: 'PT', fromX: 334, fromY: 265, toX: 232, toY: 342, controlYOffset: -35 }
  ];

  // Colors coordinating with compliance status guidelines
  const getExposureStatus = (code: string) => {
    const days = daysSummary[code] || 0;
    const rule = rules.find(r => r.countryCode === code);
    if (!rule) return {
      level: 'Operational',
      colorHex: '#10b981',
      colorBg: 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400',
      colorText: 'text-emerald-400',
    };

    if (rule.minDaysRequired && days < rule.minDaysRequired) {
      return {
        level: 'Target Pending',
        colorHex: '#cca568',
        colorBg: 'bg-amber-500/10 border-amber-500/25 text-amber-400',
        colorText: 'text-amber-400',
      };
    }

    const maxLimit = rule.maxDaysLimit;
    if (days >= maxLimit) {
      return {
        level: 'Threshold Exceeded',
        colorHex: '#f43f5e',
        colorBg: 'bg-rose-500/15 border-rose-500/25 text-rose-400',
        colorText: 'text-rose-400',
      };
    } else if (days >= maxLimit - rule.warningThresholdDays) {
      return {
        level: 'Approaching Limit',
        colorHex: '#f59e0b',
        colorBg: 'bg-amber-500/15 border-amber-500/25 text-amber-400',
        colorText: 'text-amber-300',
      };
    }

    return {
      level: 'Within Safe Range',
      colorHex: '#10b981',
      colorBg: 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400',
      colorText: 'text-emerald-400',
    };
  };

  const displayedHub = hoveredHub || hubs.find(h => h.code === activeCountryCode) || null;
  const currentDays = displayedHub ? (daysSummary[displayedHub.code] || 0) : 0;
  const currentRule = displayedHub ? rules.find(r => r.countryCode === displayedHub.code) : null;
  const currentStatus = displayedHub ? getExposureStatus(displayedHub.code) : null;

  // Compute stats for overlay card
  let overlayMessage = "";
  let percentageValue = 0;
  let limitLabel = "Threshold Limit";
  let targetLimitDays = 183;

  if (displayedHub) {
    if (currentRule) {
      if (currentRule.minDaysRequired) {
        limitLabel = "Minimum Stay Target";
        targetLimitDays = currentRule.minDaysRequired;
        const remaining = Math.max(0, currentRule.minDaysRequired - currentDays);
        percentageValue = Math.min(100, Math.round((currentDays / currentRule.minDaysRequired) * 100));
        if (remaining > 0) {
          overlayMessage = `${remaining} days remaining to reach target`;
        } else {
          overlayMessage = "Target successfully accomplished";
        }
      } else {
        limitLabel = "Maximum Stay Limit";
        targetLimitDays = currentRule.maxDaysLimit;
        const remaining = Math.max(0, currentRule.maxDaysLimit - currentDays);
        percentageValue = Math.min(100, Math.round((currentDays / currentRule.maxDaysLimit) * 100));
        if (remaining > 0) {
          overlayMessage = `${remaining} buffer days remaining`;
        } else {
          overlayMessage = "Zero buffer remaining";
        }
      }
    } else {
      // General standard thresholds for ES/PT tracking if not specified in default state rules
      const standardLimit = 183;
      limitLabel = "Default Stay Limit";
      targetLimitDays = standardLimit;
      const remaining = Math.max(0, standardLimit - currentDays);
      percentageValue = Math.min(100, Math.round((currentDays / standardLimit) * 100));
      if (remaining > 0) {
        overlayMessage = `${remaining} days remaining to reach limit`;
      } else {
        overlayMessage = "Limit ratio achieved";
      }
    }
  }

  return (
    <div id="expatiq-map-card" className="relative bg-[#090a10] border border-zinc-900/80 rounded-2xl p-4 md:p-6 overflow-hidden select-none font-sans shadow-2xl space-y-4">
      
      {/* HEADER ROW - Premium minimalist styling */}
      <div className="flex flex-col sm:flex-row justify-between items-start gap-3 border-b border-zinc-900 pb-4">
        <div className="space-y-1 text-left">
          <div className="flex items-center gap-1.5 font-mono text-[9px] text-[#cca568] uppercase tracking-widest font-extrabold">
            <Globe className="w-3.5 h-3.5 stroke-[1.5] text-[#38bdf8]" />
            <span>EXPATIQ GEOGRAPHIC LEDGER</span>
          </div>
          <h2 className="text-sm font-bold uppercase tracking-tight text-zinc-100 font-sans">
            European Residency Mobility Map
          </h2>
          <p className="text-[10.5px] text-zinc-500">
            High-fidelity geographical tracking of statutory days, border entries, and physical presence.
          </p>
        </div>

        {/* Minimal Luxury Scale */}
        <div className="flex flex-wrap gap-x-3 gap-y-1.5 font-mono text-[8px] text-zinc-500 uppercase">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 bg-[#38bdf8] rounded-full shadow-[0_0_8px_rgba(56,189,248,0.5)]"></span>
            Monaco Base
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 bg-[#10b981] rounded-full"></span>
            Safe Range
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 bg-[#f59e0b] rounded-full"></span>
            Approaching
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 bg-[#f43f5e] rounded-full"></span>
            Exceeded
          </span>
        </div>
      </div>

      {/* CORE HERO VISUALIZATION */}
      <div className="relative h-88 sm:h-[440px] md:h-[500px] w-full bg-[#030406] rounded-xl border border-zinc-950/70 overflow-hidden flex items-center justify-center shadow-inner">
        
        {/* Fine-grained luxury coordinate grids */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.012)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.012)_1px,transparent_1px)] bg-[size:30px_30px] pointer-events-none"></div>

        {/* Dynamic deep slate vignette aura */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_15%,#010203_96%)] pointer-events-none"></div>

        {/* Deep atmospheric radar satellite glow centered on Europe */}
        <div className="absolute top-[45%] left-[35%] -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-sky-500/5 blur-[100px] rounded-full pointer-events-none"></div>

        {/* REAL VECTOR WORLD MAP PROJECTION (European residency focus zoom crop) */}
        <svg 
          className="absolute inset-0 w-full h-full select-none" 
          viewBox="185 55 490 380"
          preserveAspectRatio="xMidYMid slice"
        >
          {/* Defs containing rendering enhancements such as an elegant Gaussian blur feather filter */}
          <defs>
            <filter id="premium-map-blur" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="0.4" />
            </filter>
          </defs>

          {/* Subtle reference coordinate indicators */}
          <g stroke="rgba(255,255,255,0.015)" strokeWidth="0.5" fill="none" className="pointer-events-none">
            <line x1="100" y1="0" x2="100" y2="480" strokeDasharray="3 6" />
            <line x1="200" y1="0" x2="200" y2="480" strokeDasharray="3 6" />
            <line x1="300" y1="0" x2="300" y2="480" strokeDasharray="3 6" />
            <line x1="400" y1="0" x2="400" y2="480" strokeDasharray="3 6" />
            <line x1="500" y1="0" x2="500" y2="480" strokeDasharray="3 6" />
            <line x1="600" y1="0" x2="600" y2="480" strokeDasharray="3 6" />
            <line x1="700" y1="0" x2="700" y2="480" strokeDasharray="3 6" />
            <line x1="0" y1="100" x2="800" y2="100" strokeDasharray="3 6" />
            <line x1="0" y1="200" x2="800" y2="200" strokeDasharray="3 6" />
            <line x1="0" y1="300" x2="800" y2="300" strokeDasharray="3 6" />
            <line x1="0" y1="400" x2="800" y2="400" strokeDasharray="3 6" />
          </g>

          {/* REAL ACCURATE WORLD GEOGRAPHY ASSET - Matte silver-gray land masses with soft blur feathering */}
          <g 
            fill="rgba(215, 225, 240, 0.22)" 
            stroke="rgba(255, 255, 255, 0.28)" 
            strokeWidth="0.7" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            filter="url(#premium-map-blur)"
            shapeRendering="geometricPrecision"
          >
            {/* Eurasia (Europe, Russia, Asia & India Peninsula) */}
            <path id="eurasia" d="
              M 285,150 
              C 280,125 290,115 292,105 
              C 298,100 304,103 308,111 
              C 305,125 295,135 298,150 
              C 301,167 318,177 314,187 
              C 310,197 298,200 290,195 
              C 288,187 285,183 278,180 
              C 270,175 272,160 275,150 Z 
              
              M 360,180
              C 355,150 368,120 380,100
              C 392,80 412,60 432,50
              C 445,43 458,47 462,57
              C 458,75 445,90 440,110
              C 430,130 418,150 412,167
              C 408,180 398,190 388,185
              C 382,183 375,187 360,180 Z
              
              M 440,110
              C 452,95 470,60 480,55
              C 488,60 492,77 488,100
              C 482,120 472,140 468,150
              C 460,153 448,150 440,140 Z
              
              M 225,330 
              L 285,320 
              C 295,321 300,330 304,340 
              C 300,360 290,385 270,390 
              C 248,395 225,390 220,370 
              C 215,353 218,340 225,330 Z 
              
              M 292,230 
              L 325,230 
              C 345,235 355,243 360,257 
              L 368,280 
              C 362,297 352,300 332,303 
              C 315,305 302,310 285,310 
              L 292,230 Z 
              
              M 358,277 
              C 370,281 378,287 382,295 
              L 398,330 
              C 408,350 420,370 425,380 
              C 418,383 412,380 408,373 
              L 392,343 
              L 375,317 
              C 368,300 360,287 358,277 Z 
              
              M 325,230 
              L 365,213 
              L 390,213 
              L 420,217 
              L 440,227 
              L 450,247 
              L 410,277 
              L 378,277 
              L 360,260 Z 
              
              M 408,277 
              L 450,280 
              L 460,333 
              C 455,350 442,360 438,355 
              L 428,335 Z 
              
              M 478,307 
              L 555,303 
              L 572,320 
              L 562,343 
              L 498,347 
              L 478,325 Z
              
              M 560,350 
              C 585,345 615,350 625,360 
              C 638,367 652,373 662,363 
              C 675,367 690,377 710,390 
              C 730,405 735,420 745,435 
              L 755,463 
              C 745,480 725,490 702,485 
              C 675,475 652,470 628,473 
              L 602,463 
              C 588,445 582,417 578,390 Z
              
              M 412,167 
              L 465,160 
              C 490,140 540,135 595,145 
              C 630,150 660,130 710,120 
              C 745,115 780,130 795,155 
              C 798,185 785,250 770,280 
              C 750,310 700,340 660,345 
              C 610,350 540,340 500,320 
              C 480,310 460,290 448,270 
              L 412,167 Z
            " />

            {/* North America (Extreme western slivers beautifully co-existing in background crop) */}
            <path id="north-america" d="
              M 25,60 
              L 140,55 
              L 170,80 
              L 130,110 
              L 135,130 
              L 160,145 
              L 145,155 
              L 125,138 
              L 95,135 
              L 75,110 
              L 45,105 Z
              
              M 160,35 
              L 190,30 
              L 200,60 
              L 170,75 Z
            " />

            {/* South America (Extreme western sliver crop) */}
            <path id="south-america" d="
              M 145,155 
              L 195,185 
              L 215,220 
              L 190,290 
              L 160,360 
              L 140,410 
              L 130,430 
              L 115,410 
              L 120,340 
              L 110,240 L 122,190 Z
            " />

            {/* Africa (Framing the Mediterranean elegantly from the South) */}
            <path id="africa" d="
              M 195,315 
              C 202,313 210,315 210,322 
              C 206,326 198,326 195,315 Z

              M 160,410 
              C 170,405 195,397 218,387 
              C 222,383 232,387 270,393 
              C 292,395 335,393 352,397 
              C 356,397 368,393 375,403 
              L 380,420 
              C 372,430 358,437 352,445 
              L 382,478 
              C 300,480 220,480 160,475 Z
              
              M 255,305 
              L 350,307 
              L 385,325 
              L 415,375 
              L 375,445 
              L 340,475 
              L 315,465 
              L 295,435 L 255,412 Z" />

            {/* Australia */}
            <path id="australia" d="
              M 650,370 
              L 715,375 
              L 735,420 
              L 695,450 
              L 640,430 L 650,370 Z
            " />

            {/* Core Mediterranean Islands */}
            <path id="sicily" d="M 422,406 C 430,405 435,412 428,416 C 420,416 418,408 422,406 Z" />
            <path id="sardinia" d="M 368,338 C 374,338 373,352 368,352 C 364,352 364,338 368,338 Z" />
            <path id="corsica" d="M 370,318 C 374,318 374,326 371,328 C 368,328 368,318 370,318 Z" />
          </g>

          {/* AVIATION TRAVEL FLIGHT PATHS - Thin luxury curves with moving pulsing beacons */}
          {routes.map((route) => {
            const midX = (route.fromX + route.toX) / 2;
            const midY = (route.fromY + route.toY) / 2 - route.controlYOffset;
            const pathData = `M ${route.fromX} ${route.fromY} Q ${midX} ${midY} ${route.toX} ${route.toY}`;
            
            return (
              <g key={route.id} className="pointer-events-none">
                {/* Underglow route track (Subtle premium aura) */}
                <path
                  d={pathData}
                  fill="none"
                  stroke="rgba(56, 189, 248, 0.08)"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  opacity="0.4"
                />
                
                {/* Thin, elegant flight trajectory (Distinct soft white/blue, ultra thin) */}
                <path
                  d={pathData}
                  fill="none"
                  stroke="rgba(215, 237, 255, 0.45)"
                  strokeWidth="0.8"
                  strokeDasharray="3 3"
                />

                {/* Premium double aviation pulse beacon (Active motion tracking aura) */}
                <circle r="2.2" fill="#38bdf8" opacity="0.32" className="animate-pulse">
                  <animateMotion
                    path={pathData}
                    dur={route.id === 'route-monaco-uk' ? '12s' : route.id === 'route-monaco-finland' ? '16s' : '20s'}
                    repeatCount="indefinite"
                  />
                </circle>
                <circle r="1.1" fill="#ffffff" className="shadow-lg">
                  <animateMotion
                    path={pathData}
                    dur={route.id === 'route-monaco-uk' ? '12s' : route.id === 'route-monaco-finland' ? '16s' : '20s'}
                    repeatCount="indefinite"
                  />
                </circle>
              </g>
            );
          })}

          {/* EXPATIQ GEOGRAPHIC NODES */}
          {hubs.map((hub) => {
            const isSelected = activeCountryCode === hub.code;
            const isUserCurrent = hub.code === 'MC';
            
            const status = getExposureStatus(hub.code);
            const isActive = isSelected || isUserCurrent;
            const markerColor = isActive ? '#38bdf8' : status.colorHex;

            return (
              <g 
                key={hub.code} 
                className="cursor-pointer group select-none"
                onClick={() => onSelectCountryCode(hub.code)}
                onMouseEnter={() => setHoveredHub(hub)}
                onMouseLeave={() => setHoveredHub(null)}
              >
                {/* Soft glow radar boundary rings */}
                <circle 
                  cx={hub.x} 
                  cy={hub.y} 
                  r={isSelected ? 14 : 9} 
                  fill="none" 
                  stroke={markerColor} 
                  strokeWidth={isSelected ? 1.5 : 0.75}
                  opacity={isSelected ? 0.45 : 0.15} 
                  className="transition-all duration-300 pointer-events-none"
                />

                {/* Glowing pulse ring exclusively for the current location or manual override selections */}
                {isActive && (
                  <circle 
                    cx={hub.x} 
                    cy={hub.y} 
                    r="12" 
                    fill="none" 
                    stroke="#38bdf8" 
                    strokeWidth="1.0" 
                    opacity="0.55" 
                    className="animate-ping pointer-events-none" 
                    style={{ animationDuration: '3.0s' }}
                  />
                )}

                {/* Primary physical marker */}
                <circle 
                  cx={hub.x} 
                  cy={hub.y} 
                  r={isSelected ? 5 : 3.5} 
                  fill={markerColor}
                  stroke="#030406"
                  strokeWidth="1.25"
                  className="transition-all duration-300 group-hover:scale-125 shadow-lg"
                />

                {/* Compact elegant text tag */}
                <g transform={`translate(${hub.x + 6}, ${hub.y - 4})`} className="pointer-events-none">
                  <rect 
                    width="15" 
                    height="8" 
                    rx="1.2" 
                    fill="#030406" 
                    stroke={isSelected ? "#38bdf8" : "rgba(255,255,255,0.18)"} 
                    strokeWidth="0.6" 
                  />
                  <text 
                    x="7.5" 
                    y="6" 
                    textAnchor="middle" 
                    className={`font-mono text-[5.5px] font-black tracking-tight ${isSelected ? 'fill-sky-200' : 'fill-zinc-400'}`}
                  >
                    {hub.code}
                  </text>
                </g>

                {/* Monaco specific active residence label for high clarity */}
                {isUserCurrent && (
                  <g transform={`translate(${hub.x - 52}, ${hub.y + 13})`} className="pointer-events-none">
                    <rect 
                      width="104" 
                      height="15" 
                      rx="3" 
                      fill="rgba(3, 4, 6, 0.96)" 
                      stroke="rgba(56, 189, 248, 0.55)" 
                      strokeWidth="0.75" 
                    />
                    <circle cx="8" cy="7.5" r="1.5" fill="#38bdf8" className="animate-pulse" />
                    <text 
                      x="16" 
                      y="9.8" 
                      className="font-sans text-[5.5px] font-black tracking-widest fill-sky-200"
                    >
                      MONACO • CURRENT RESIDENCY
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>

        {/* FLOATING GLASS DOSSIER CARD - ExpatIQ Refined, Compact Overlay Widget */}
        {displayedHub && currentStatus && (() => {
          const remainingDaysLeft = currentRule
            ? (currentRule.minDaysRequired
                ? Math.max(0, currentRule.minDaysRequired - currentDays)
                : Math.max(0, currentRule.maxDaysLimit - currentDays))
            : Math.max(0, 183 - currentDays);

          const remainingText = currentRule?.minDaysRequired 
            ? `${remainingDaysLeft} days remaining`
            : `${remainingDaysLeft} buffer remaining`;

          return (
            <div 
              id="floating-residency-widget" 
              className="absolute top-4 left-4 bg-zinc-950/35 border border-white/10 p-3.5 rounded-xl w-52 sm:w-56 pointer-events-none select-none z-30 backdrop-blur-md shadow-[0_12px_32px_rgba(0,0,0,0.18)] text-left animate-fadeIn transition-all space-y-3"
            >
              {/* Country Name, Flag and Target Status */}
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm leading-none" role="img" aria-label={`Flag of ${displayedHub.name}`}>
                    {displayedHub.flag}
                  </span>
                  <span className="text-xs font-bold text-zinc-100 font-sans tracking-tight">
                    {displayedHub.name}
                  </span>
                </div>
                <span className={`text-[7px] font-mono font-bold tracking-wider px-1.5 py-0.5 rounded-full border leading-none ${currentStatus.colorBg}`}>
                  {currentStatus.level.toUpperCase()}
                </span>
              </div>

              {/* Tracks Status (Tracked vs Remaining) */}
              <div className="flex justify-between items-center text-[10px] font-sans font-medium text-zinc-200 leading-none">
                <span>{currentDays} days tracked</span>
                <span className="text-zinc-400">
                  {remainingText}
                </span>
              </div>

              {/* Slim progress bar */}
              <div className="h-[2px] bg-white/10 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-550 ${
                    displayedHub.code === 'MC' ? 'bg-sky-400 shadow-[0_0_6px_rgba(56,189,248,0.5)]' :
                    currentStatus.colorHex === '#f43f5e' ? 'bg-rose-500' :
                    currentStatus.colorHex === '#cca568' || currentStatus.colorHex === '#f59e0b' ? 'bg-amber-400' :
                    'bg-emerald-500'
                  }`}
                  style={{ width: `${percentageValue}%` }}
                />
              </div>

            </div>
          );
        })()}
      </div>

      {/* CORE STATUTORY DETAILS CARDS - Grid tracking */}
      <div className="mt-4 grid grid-cols-2 lg:grid-cols-4 gap-3 text-zinc-400 text-left">
        {rules.map((rule) => {
          const days = daysSummary[rule.countryCode] || 0;
          const status = getExposureStatus(rule.countryCode);
          const hasMin = rule.minDaysRequired;
          const percentage = rule.minDaysRequired
            ? Math.min(100, Math.round((days / rule.minDaysRequired) * 100))
            : Math.min(100, Math.round((days / rule.maxDaysLimit) * 100));

          const isSelected = activeCountryCode === rule.countryCode;

          return (
            <div
              key={rule.id}
              onClick={() => onSelectCountryCode(rule.countryCode)}
              className={`bg-[#07080d] border rounded-xl p-3.5 cursor-pointer hover:border-sky-500/40 transition-all flex flex-col justify-between ${
                isSelected ? 'border-sky-500 bg-[#0a0a14] shadow-md' : 'border-zinc-900'
              }`}
            >
              <div className="space-y-1">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] font-mono text-zinc-500 tracking-wider font-bold">
                    {rule.countryCode} TARGET
                  </span>
                  
                  <span className={`text-[8.5px] font-mono font-extrabold px-1.5 py-0.5 rounded border ${status.colorBg}`}>
                    {days} Days
                  </span>
                </div>

                <div className="text-xs font-bold text-zinc-200 uppercase font-sans tracking-tight">
                  {rule.countryName}
                </div>
              </div>

              {/* Minimalist Progress Indicator */}
              <div className="mt-3 space-y-1 font-mono">
                <div className="flex justify-between text-[8px] text-zinc-500">
                  <span>{hasMin ? 'MIN REQUIRED' : 'MAX COMPLIANCE'}</span>
                  <span className="text-zinc-450">{hasMin ? rule.minDaysRequired : rule.maxDaysLimit}d Limit</span>
                </div>
                <div className="h-1 bg-zinc-900/60 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${percentage}%` }}
                    className={`h-full rounded-full transition-all duration-300 ${
                      rule.countryCode === 'MC' ? 'bg-sky-450' :
                      status.colorHex === '#f43f5e' ? 'bg-rose-500' :
                      status.colorHex === '#cca568' || status.colorHex === '#f59e0b' ? 'bg-amber-400' :
                      'bg-emerald-500'
                    }`}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
