/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Calendar, 
  FileText, 
  Mail, 
  Import, 
  Check, 
  Sparkles, 
  Wallet, 
  Compass, 
  ArrowRight,
  Clock,
  Globe,
  Upload
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TravelLog } from '../types';

interface EcosystemIntegrationsProps {
  onAddLog: (log: Omit<TravelLog, 'id'>) => void;
  onAddEvidence: (file: any) => void;
}

export default function EcosystemIntegrations({ onAddLog, onAddEvidence }: EcosystemIntegrationsProps) {
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [parsingLoader, setParsingLoader] = useState<string | null>(null);

  // Simulated ticket imports that add real entries to the timeline for validation
  const mockIntegrations = [
    {
      id: 'gcal',
      name: 'Google Calendar Sync',
      desc: 'Scan double commitments, ski resort accommodations, and executive board meetings.',
      cta: 'Sync Calendar',
      icon: Calendar,
      trigger: () => {
        setParsingLoader('Scanning Google Calendar for international border triggers...');
        setTimeout(() => {
          onAddLog({
            countryCode: 'CH',
            countryName: 'Switzerland',
            entryDate: '2026-06-15',
            exitDate: '2026-06-21',
            notes: 'AUTOMATED CALENDAR DETECT: Asset wealth management board sessions, Zurich',
            verifiedMethod: 'Digital Stamp'
          });
          setSuccessMsg('Successfully synced & registered calendar slot: 6 days stay in Switzerland calculated!');
          setParsingLoader(null);
        }, 1800);
      }
    },
    {
      id: 'boarding-pass',
      name: 'Apple Boarding Pass import',
      desc: 'Import Apple Wallet Pass PKPass tickets with digital security stamps.',
      cta: 'Parse Apple Wallet',
      icon: Wallet,
      trigger: () => {
        setParsingLoader('Extracting Flight itinerary metadata details...');
        setTimeout(() => {
          onAddLog({
            countryCode: 'UK',
            countryName: 'United Kingdom',
            entryDate: '2026-10-02',
            exitDate: '2026-10-04',
            notes: 'AUTOMATED PASS DECOMPILER: Nice Côte d’Azur to London Heathrow (British Airways VIP Lounge)',
            verifiedMethod: 'Boarding Pass'
          });
          onAddEvidence({
            id: `env-${Math.random().toString().substring(2, 6)}`,
            fileName: 'BRITISH_AIRWAYS_BA321_NICE_TO_LHR.pdf',
            fileType: 'Boarding Pass',
            uploadDate: '2026-05-24',
            fileSize: '1.4 MB',
            countryCode: 'UK',
            status: 'Verified',
            notes: 'Parsed from Apple Wallet digital boarding pass'
          });
          setSuccessMsg('Apple Wallet parsed: UK business trip recorded on October 2-4 and attached to evidence vault.');
          setParsingLoader(null);
        }, 2100);
      }
    },
    {
      id: 'gmail-flighty',
      name: 'Gmail & Flighty Hub parser',
      desc: 'Process booking confirmations, flight receipts, and real-time Flighty travel state signals.',
      cta: 'Auth Flighty OAuth',
      icon: Import,
      trigger: () => {
        setParsingLoader('Compiling airline API schemas & Flighty state feeds...');
        setTimeout(() => {
          onAddLog({
            countryCode: 'AE',
            countryName: 'United Arab Emirates',
            entryDate: '2026-11-10',
            exitDate: '2026-11-20',
            notes: 'AUTOMATED FLIGHTY PARSE: Dubai World AI summits (Emirates EK109 Business Class)',
            verifiedMethod: 'GPS'
          });
          setSuccessMsg('Flighty parsing complete: Detected prospective UAE tech excursion on Nov 10-20.');
          setParsingLoader(null);
        }, 1500);
      }
    }
  ];

  return (
    <div className="space-y-6">
      
      {/* 1. Header Information */}
      <div className="bg-[#0b0c10] border border-zinc-900 rounded-2xl p-5 space-y-4">
        <div className="flex justify-between items-center">
          <div className="space-y-1">
            <span className="text-[9px] font-mono text-amber-500 uppercase tracking-widest font-bold">AUTOMATED TRAVEL CAPTURE</span>
            <h3 className="text-sm font-bold text-zinc-100 uppercase tracking-tight">API & Wallet Parsing Ecosystem</h3>
            <p className="text-[10.5px] text-zinc-500 font-serif leading-relaxed italic">Incorporate third-party signals into your active residency ledger. Cross-reference GPS verification to minimize audit risks from missing data gaps.</p>
          </div>
          <Import className="w-5 h-5 text-zinc-600" />
        </div>

        {/* Dynamic Parsing action loaders */}
        <AnimatePresence>
          {parsingLoader && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="p-3.5 bg-zinc-950 border border-zinc-905 rounded-xl flex items-center gap-3 justify-center text-center overflow-hidden"
            >
              <Clock className="w-4 h-4 text-amber-500 animate-spin" />
              <span className="text-[10.5px] font-mono text-zinc-350">{parsingLoader}</span>
            </motion.div>
          )}

          {successMsg && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="p-3.5 bg-emerald-500/10 border border-emerald-500/25 rounded-xl flex items-start gap-3 overflow-hidden text-left"
            >
              <Check className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
              <div className="space-y-1">
                <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-wide">Import Completed Securely</span>
                <p className="text-xs text-zinc-300 leading-snug">{successMsg}</p>
                <button
                  onClick={() => setSuccessMsg(null)}
                  className="text-[9px] font-mono text-zinc-500 underline uppercase hover:text-white"
                >
                  Dismiss notice
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* List of Integrations with pristine visual boxes */}
        <div className="space-y-3.5 pt-2">
          {mockIntegrations.map((item) => {
            const IconComponent = item.icon;
            return (
              <div 
                key={item.id}
                className="p-3.5 bg-zinc-950 border border-zinc-905 rounded-xl hover:border-zinc-805 transition-all flex justify-between items-center group"
              >
                <div className="flex gap-3 items-start pr-4">
                  <div className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-400 group-hover:text-amber-400 transition-colors">
                    <IconComponent className="w-4 h-4 shrink-0" />
                  </div>
                  <div className="space-y-0.5">
                    <h4 className="text-xs font-bold text-zinc-200">{item.name}</h4>
                    <p className="text-[10.5px] text-zinc-500 leading-snug">{item.desc}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={item.trigger}
                  className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-850 hover:text-amber-400 border border-zinc-800 text-[10.5px] font-mono uppercase rounded text-zinc-200 tracking-wider font-bold shrink-0 transition-colors"
                >
                  {item.cta}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
