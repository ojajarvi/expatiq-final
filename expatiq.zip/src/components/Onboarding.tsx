/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { 
  ShieldCheck, 
  MapPin, 
  Bell, 
  Navigation, 
  Check, 
  ChevronRight, 
  ChevronLeft, 
  Globe, 
  Sparkles, 
  Sliders, 
  Lock, 
  Compass,
  AlertTriangle,
  Flame,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TaxRule } from '../types';

interface OnboardingProps {
  onComplete: (data: {
    primaryTaxHome: string;
    rules: TaxRule[];
    locationTracking: boolean;
    notifications: string[];
  }) => void;
}

const NATIONS = [
  { code: 'MC', name: 'Monaco', defaultMax: 365, defaultMin: 90, desc: '90 days minimum physical presence target for fiscal certificate.' },
  { code: 'AE', name: 'UAE (Dubai)', defaultMax: 365, defaultMin: 90, desc: '90 days minimum presence rule for physical visa residency.' },
  { code: 'CH', name: 'Switzerland', defaultMax: 90, defaultMin: 0, desc: '90 days maximum non-working presence standard limit.' },
  { code: 'FI', name: 'Finland', defaultMax: 183, defaultMin: 0, desc: '183 days maximum residency threshold for global income exposure.' },
  { code: 'UK', name: 'United Kingdom', defaultMax: 90, defaultMin: 0, desc: 'Statutory Residence Test (often triggered at 90+ days).' },
  { code: 'PT', name: 'Portugal', defaultMax: 183, defaultMin: 0, desc: '183 days maximum threshold for tax compliance.' },
  { code: 'ES', name: 'Spain', defaultMax: 183, defaultMin: 0, desc: 'Accidental resident status triggered on day 184.' },
  { code: 'US', name: 'United States', defaultMax: 120, defaultMin: 0, desc: 'Substantial Presence Formula standard constraint.' },
];

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState<number>(1);
  const [primaryTaxHome, setPrimaryTaxHome] = useState<string>('MC');
  const [monitoredCountries, setMonitoredCountries] = useState<string[]>(['FI', 'UK']);
  
  // Custom states to manage rules temporarily during onboarding
  const [rules, setRules] = useState<TaxRule[]>([
    {
      id: 'rule-fi',
      countryCode: 'FI',
      countryName: 'Finland',
      maxDaysLimit: 183,
      warningThresholdDays: 20,
      description: 'Avoid accidental tax residency threshold.'
    },
    {
      id: 'rule-uk',
      countryCode: 'UK',
      countryName: 'United Kingdom',
      maxDaysLimit: 90,
      warningThresholdDays: 14,
      description: 'Sufficient Ties Test strict threshold.'
    },
    {
      id: 'rule-mc',
      countryCode: 'MC',
      countryName: 'Monaco',
      maxDaysLimit: 365,
      minDaysRequired: 90,
      warningThresholdDays: 30,
      description: 'Luxury Mediterranean Hub minimum presence requirement.'
    }
  ]);

  const [locationTracking, setLocationTracking] = useState<boolean>(true);
  const [notifications, setNotifications] = useState<string[]>([
    '30d', '14d', '7d', 'daily'
  ]);

  const toggleMonitoredCountry = (code: string) => {
    if (code === primaryTaxHome) return; // Primary home is monitored differently
    if (monitoredCountries.includes(code)) {
      const updatedMonitored = monitoredCountries.filter(c => c !== code);
      setMonitoredCountries(updatedMonitored);
      // Remove rule only if there is a match and it is not the primary tax home
      setRules(prevRules => {
        const filtered = prevRules.filter(r => r.countryCode !== code || r.countryCode === primaryTaxHome);
        const uniqueMap = new Map<string, TaxRule>();
        filtered.forEach(r => uniqueMap.set(r.countryCode, r));
        return Array.from(uniqueMap.values());
      });
    } else {
      const updatedMonitored = [...monitoredCountries, code];
      setMonitoredCountries(updatedMonitored);
      
      const nationInfo = NATIONS.find(n => n.code === code);
      if (nationInfo) {
        setRules(prevRules => {
          const cleanPrev = prevRules.filter(r => r.countryCode !== code);
          const uniqueMap = new Map<string, TaxRule>();
          cleanPrev.forEach(r => uniqueMap.set(r.countryCode, r));
          
          uniqueMap.set(code, {
            id: `rule-${code.toLowerCase()}`,
            countryCode: code,
            countryName: nationInfo.name,
            maxDaysLimit: nationInfo.defaultMax,
            minDaysRequired: nationInfo.defaultMin > 0 ? nationInfo.defaultMin : undefined,
            warningThresholdDays: 20,
            description: nationInfo.desc
          });
          return Array.from(uniqueMap.values());
        });
      }
    }
  };

  const handleRuleChange = (code: string, field: 'maxDaysLimit' | 'minDaysRequired' | 'warningThresholdDays', value: number) => {
    setRules(prevRules => {
      const updated = prevRules.map(r => {
        if (r.countryCode === code) {
          return {
            ...r,
            [field]: value > 0 ? value : undefined
          };
        }
        return r;
      });
      const uniqueMap = new Map<string, TaxRule>();
      updated.forEach(r => uniqueMap.set(r.countryCode, r));
      return Array.from(uniqueMap.values());
    });
  };

  const toggleNotifPref = (pref: string) => {
    if (notifications.includes(pref)) {
      setNotifications(notifications.filter(p => p !== pref));
    } else {
      setNotifications([...notifications, pref]);
    }
  };

  const totalSteps = 7;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      onComplete({
        primaryTaxHome,
        rules,
        locationTracking,
        notifications
      });
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  return (
    <div className="min-h-screen bg-[#07080a] text-zinc-100 flex flex-col justify-between p-6 max-w-md mx-auto relative font-sans">
      {/* Background soft ambient noise and glow elements */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-1/12 left-1/4 w-48 h-48 bg-emerald-500/2 rounded-full blur-3xl pointer-events-none"></div>

      {/* Header telemetry info */}
      <div className="flex justify-between items-center text-[9px] font-mono tracking-widest text-zinc-500">
        <div className="flex items-center gap-1.5">
          <Compass className="w-3.5 h-3.5 text-zinc-400 rotate-12" />
          <span>EXPATIQ RESIDENCY SETUP</span>
        </div>
        <div>STEP {step} OF {totalSteps}</div>
      </div>

      {/* Real-time elegant progress gauge line */}
      <div className="h-0.5 bg-zinc-900 w-full mt-3 rounded-full overflow-hidden flex">
        {Array.from({ length: totalSteps }).map((_, idx) => (
          <div 
            key={idx} 
            className={`h-full flex-1 transition-all duration-500 border-r border-[#07080a] last:border-0 ${
              idx + 1 <= step ? 'bg-amber-400' : 'bg-zinc-800'
            }`} 
          />
        ))}
      </div>

      {/* Dynamic Slide Components */}
      <div className="my-auto py-8 flex flex-col justify-center min-h-[380px]">
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -15 }}
            transition={{ duration: 0.25 }}
            className="space-y-6"
          >
            {/* STEP 1: WELCOME SCREEN */}
            {step === 1 && (
              <div className="space-y-6 h-full flex flex-col justify-center select-none">
                <div className="w-12 h-12 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-center relative">
                  <span className="absolute inset-0 rounded-xl bg-gradient-to-tr from-amber-400/20 to-transparent blur-md"></span>
                  <Globe className="w-6 h-6 text-amber-400" />
                </div>
                <div className="space-y-3.5">
                  <h1 className="text-3.5xl font-semibold leading-[1.125] tracking-tight text-zinc-100 bg-gradient-to-br from-white via-zinc-200 to-zinc-500 bg-clip-text text-transparent">
                    Automatic presence tracking.<br/>Verified travel documentation.
                  </h1>
                  <p className="text-zinc-400 text-[13px] leading-relaxed">
                    Track your days, exits, and entries across jurisdictions with automated presence tracking. Keep precise digital diaries to monitor local residency targets and physical presence constraints.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-zinc-900/50 border border-zinc-900/80 flex gap-3 items-start">
                  <div className="p-1 rounded bg-zinc-800 text-zinc-300">
                    <Lock className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="space-y-0.5">
                    <span className="text-[11px] font-bold text-zinc-200 uppercase font-mono tracking-wider">Encrypted & Private</span>
                    <p className="text-[11px] text-zinc-500">Your presence data is secured with device-level encryption. Verified residency reports are exported solely under your direct instruction as formal travel documentation.</p>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 2: CHOOSE PRIMARY TAX HOME */}
            {step === 2 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <span className="text-[10px] uppercase tracking-widest font-mono text-zinc-500">RESIDENCY PROFILE</span>
                  <h2 className="text-xl font-bold text-zinc-100">Primary Resident Domain</h2>
                  <p className="text-xs text-zinc-400">
                    Select the main jurisdiction where you hold active residency / citizenship, files tax returns, or intends to maintain compliance status.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2.5 max-h-56 overflow-y-auto pr-1">
                  {NATIONS.map((nation) => {
                    const isSelected = primaryTaxHome === nation.code;
                    return (
                      <button
                        key={nation.code}
                        type="button"
                        onClick={() => {
                          const newPrimary = nation.code;
                          setPrimaryTaxHome(newPrimary);
                          
                          // Auto remove from monitored list as it is the primary base
                          const updatedMonitored = monitoredCountries.filter(c => c !== newPrimary);
                          setMonitoredCountries(updatedMonitored);

                           // Clean up rules state dynamically to prevent key clashes
                          setRules(prevRules => {
                            const uniqueMap = new Map<string, TaxRule>();
                            
                            // 1. Add existing rules that are still relevant
                            prevRules.forEach(r => {
                              if (r.countryCode === newPrimary || updatedMonitored.includes(r.countryCode)) {
                                uniqueMap.set(r.countryCode, r);
                              }
                            });

                            // 2. Add or update primary tax home rule
                            const existsPrimary = uniqueMap.get(newPrimary);
                            const primaryNationInfo = NATIONS.find(n => n.code === newPrimary);
                            if (existsPrimary) {
                              uniqueMap.set(newPrimary, {
                                ...existsPrimary,
                                minDaysRequired: primaryNationInfo && primaryNationInfo.defaultMin > 0 ? primaryNationInfo.defaultMin : undefined
                              });
                            } else if (primaryNationInfo) {
                              uniqueMap.set(newPrimary, {
                                id: `rule-${newPrimary.toLowerCase()}`,
                                countryCode: newPrimary,
                                countryName: primaryNationInfo.name,
                                maxDaysLimit: primaryNationInfo.defaultMax,
                                minDaysRequired: primaryNationInfo.defaultMin > 0 ? primaryNationInfo.defaultMin : undefined,
                                warningThresholdDays: 20,
                                description: primaryNationInfo.desc
                              });
                            }

                            // 3. Ensure all monitored countries are populated
                            updatedMonitored.forEach(code => {
                              if (!uniqueMap.has(code)) {
                                const nationInfo = NATIONS.find(n => n.code === code);
                                if (nationInfo) {
                                  uniqueMap.set(code, {
                                    id: `rule-${code.toLowerCase()}`,
                                    countryCode: code,
                                    countryName: nationInfo.name,
                                    maxDaysLimit: nationInfo.defaultMax,
                                    minDaysRequired: nationInfo.defaultMin > 0 ? nationInfo.defaultMin : undefined,
                                    warningThresholdDays: 20,
                                    description: nationInfo.desc
                                  });
                                }
                              }
                            });

                            return Array.from(uniqueMap.values());
                          });
                        }}
                        className={`p-3.5 rounded-lg border text-left transition-all ${
                          isSelected 
                            ? 'bg-amber-500/10 border-amber-400 text-zinc-100 shadow-[0_0_12px_rgba(251,191,36,0.1)]' 
                            : 'bg-zinc-900/50 border-zinc-850 hover:border-zinc-750 text-zinc-350'
                        }`}
                      >
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs font-mono font-bold">{nation.code}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-amber-400-clean bg-amber-400 text-zinc-950 rounded-full p-0.5" />}
                        </div>
                        <div className="text-xs font-semibold">{nation.name}</div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 3: ADD COUNTRIES TO MONITOR */}
            {step === 3 && (
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <span className="text-[10px] uppercase tracking-widest font-mono text-zinc-500 font-medium">RESIDENCY WATCHLIST</span>
                  <h2 className="text-xl font-bold text-zinc-100">Countries to Monitor</h2>
                  <p className="text-xs text-zinc-400">
                    Identify other countries you regularly visit for leisure, family, investments, or business and wish to monitor close day thresholds.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2.5 max-h-56 overflow-y-auto pr-1">
                  {NATIONS.filter(n => n.code !== primaryTaxHome).map((nation) => {
                    const isMonitored = monitoredCountries.includes(nation.code);
                    return (
                      <button
                        key={nation.code}
                        type="button"
                        onClick={() => toggleMonitoredCountry(nation.code)}
                        className={`p-3.5 rounded-lg border text-left transition-all ${
                          isMonitored 
                            ? 'bg-zinc-900 border-amber-400 text-zinc-100' 
                            : 'bg-zinc-950/45 border-zinc-850 hover:border-zinc-800 text-zinc-400'
                        }`}
                      >
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-[10px] font-mono font-bold">{nation.code}</span>
                          <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center text-[8px] ${
                            isMonitored ? 'bg-amber-400 border-amber-400 text-[#09090b] font-bold' : 'border-zinc-700'
                          }`}>
                            {isMonitored ? '✓' : ''}
                          </span>
                        </div>
                        <div className="text-xs font-semibold">{nation.name}</div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 4: SET RESIDENCY THRESHOLDS */}
            {step === 4 && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-widest font-mono text-zinc-500">THRESHOLD SETTINGS</span>
                  <h2 className="text-xl font-bold text-zinc-100 font-sans">Residency Limits</h2>
                  <p className="text-xs text-zinc-400">
                    Configure your residency limits. These targets represent day limits that trigger automatic presence notifications.
                  </p>
                </div>

                <div className="space-y-3 max-h-60 overflow-y-auto pr-1.5">
                  {rules.filter(r => r.countryCode !== primaryTaxHome).map((rule) => (
                    <div key={rule.id} className="p-3 bg-zinc-900/40 border border-zinc-850 rounded-lg space-y-2.5">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-zinc-200">{rule.countryName} ({rule.countryCode})</span>
                        <span className="text-[10px] font-mono text-zinc-400 bg-zinc-900 px-1.5 py-0.5 rounded">
                          Max Limit
                        </span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                          <span>Physical days threshold:</span>
                          <span className="text-amber-400 font-bold">{rule.maxDaysLimit} Days</span>
                        </div>
                        <input
                          type="range"
                          min="10"
                          max="365"
                          value={rule.maxDaysLimit}
                          onChange={(e) => handleRuleChange(rule.countryCode, 'maxDaysLimit', parseInt(e.target.value))}
                          className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                        />
                      </div>
                    </div>
                  ))}

                  {/* Monaco / Dubai specialized minimum stay rules */}
                  {rules.find(r => r.countryCode === primaryTaxHome && r.minDaysRequired) ? (
                    <div className="p-3 bg-[#0d0e14]/85 border border-amber-500/20 rounded-lg space-y-2.5">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-amber-300">
                          {rules.find(r => r.countryCode === primaryTaxHome)?.countryName} (Base)
                        </span>
                        <span className="text-[9px] font-mono text-amber-400 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/20 select-none">
                          Presence Required Target
                        </span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                          <span>Minimum presence days:</span>
                          <span className="text-emerald-400 font-bold">
                            {rules.find(r => r.countryCode === primaryTaxHome)?.minDaysRequired} Days
                          </span>
                        </div>
                        <input
                          type="range"
                          min="30"
                          max="183"
                          value={rules.find(r => r.countryCode === primaryTaxHome)?.minDaysRequired || 90}
                          onChange={(e) => handleRuleChange(primaryTaxHome, 'minDaysRequired', parseInt(e.target.value))}
                          className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
                        />
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>
            )}

            {/* STEP 5: ENABLE LOCATION TRACKING */}
            {step === 5 && (
              <div className="space-y-5 flex flex-col justify-center select-none text-center">
                <div className="w-14 h-14 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-center relative mx-auto">
                  <span className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-emerald-500/20 to-transparent blur-md"></span>
                  <Navigation className="w-6 h-6 text-emerald-400 animate-pulse" />
                </div>
                
                <div className="space-y-2">
                  <h2 className="text-xl font-bold text-zinc-100 font-sans">Automatically Track Presence</h2>
                  <p className="text-xs text-zinc-400 max-w-sm mx-auto leading-relaxed">
                    Optionally enable background presence checks to calculate your stay durations automatically. Avoid manual entry errors or diary omissions.
                  </p>
                </div>

                <div className="bg-zinc-900/50 border border-zinc-850 rounded-xl p-4 space-y-3.5 text-left max-w-xs mx-auto">
                  <div className="flex gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span className="text-[11px] text-zinc-300">Data never leaves this browser instance. Local, absolute privacy.</span>
                  </div>
                  <div className="flex gap-2.5">
                    <Lock className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                    <span className="text-[11px] text-zinc-300 font-sans">Dynamic presence checks consume less than 0.2% battery per 24 hours.</span>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setLocationTracking(true)}
                    className={`px-5 py-2 rounded-full border text-xs font-mono tracking-widest transition-all ${
                      locationTracking 
                        ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400' 
                        : 'border-zinc-800 text-zinc-500 hover:text-zinc-400'
                    }`}
                  >
                    GPS ACTIVE
                  </button>
                  <button
                    type="button"
                    onClick={() => setLocationTracking(false)}
                    className={`px-5 py-2 rounded-full border text-xs font-mono tracking-widest transition-all ${
                      !locationTracking 
                        ? 'bg-zinc-800 border-zinc-700 text-zinc-300' 
                        : 'border-zinc-900 text-zinc-650 hover:text-zinc-500'
                    }`}
                  >
                    MANUAL LOGS ONLY
                  </button>
                </div>
              </div>
            )}

            {/* STEP 6: NOTIFICATION PREFERENCES */}
            {step === 6 && (
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <span className="text-[10px] uppercase tracking-widest font-mono text-zinc-500">INTELLIGENT NOTIFICATIONS</span>
                  <h2 className="text-xl font-bold text-zinc-100 font-sans">Presence Indicators</h2>
                  <p className="text-xs text-zinc-400">
                    Receive discreet reminders when your physical stay durations approach target boundaries.
                  </p>
                </div>

                <div className="space-y-2.5">
                  {[
                    { id: '30d', label: '30 Days before threshold', sub: 'Standard advance notification for general travel planning.' },
                    { id: '14d', label: '14 Days threshold notice', sub: 'Notification to help you map upcoming travel parameters.' },
                    { id: '7d', label: '7 Days threshold notice', sub: 'Discreet calendar countdown update.' },
                    { id: 'daily', label: 'Daily Status Updates inside risk zones', sub: 'Daily status updates to maintain absolute peace of mind.' }
                  ].map((item) => {
                    const isChecked = notifications.includes(item.id);
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => toggleNotifPref(item.id)}
                        className={`w-full text-left p-3 rounded-lg border flex gap-3.5 items-center transition-all ${
                          isChecked 
                            ? 'bg-zinc-900 border-amber-400' 
                            : 'bg-zinc-950/40 border-zinc-850 hover:bg-zinc-900/10'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                          isChecked ? 'bg-amber-400 border-amber-400 text-zinc-950 font-bold text-[9px]' : 'border-zinc-700'
                        }`}>
                          {isChecked ? '✓' : ''}
                        </div>
                        <div className="space-y-0.5">
                          <div className="text-xs font-semibold text-zinc-200">{item.label}</div>
                          <p className="text-[10px] text-zinc-500">{item.sub}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 7: FINAL SUCCESS SCREEN */}
            {step === 7 && (
              <div className="space-y-6 flex flex-col justify-center select-none text-center">
                <div className="w-16 h-16 bg-zinc-900 border border-zinc-800 rounded-3xl flex items-center justify-center relative mx-auto">
                  <span className="absolute inset-0 rounded-3xl bg-gradient-to-tr from-amber-400/20 to-transparent blur-md"></span>
                  <ShieldCheck className="w-8 h-8 text-amber-400" />
                </div>

                <div className="space-y-2">
                  <h2 className="text-2.5xl font-bold tracking-tight text-zinc-100 font-sans">Your residency calendar is active.</h2>
                  <p className="text-zinc-400 text-xs max-w-xs mx-auto leading-relaxed">
                    Residency rules configured successfully. Presence tracking engine active with end-to-end local encryption.
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-[#08090b] p-3 rounded-lg border border-zinc-900 max-w-xs mx-auto text-left font-mono text-[9px] text-[#8a8a93]">
                  <div>
                    <span className="text-zinc-600 block">BASE HOME</span>
                    <span className="text-zinc-200 font-bold">{primaryTaxHome}</span>
                  </div>
                  <div>
                    <span className="text-zinc-600 block">MONITORING</span>
                    <span className="text-zinc-200 font-bold">{monitoredCountries.length} countries</span>
                  </div>
                  <div>
                    <span className="text-zinc-600 block">PROTECTION</span>
                    <span className="text-emerald-400 font-bold">ACTIVE</span>
                  </div>
                </div>

                <p className="text-[9px] text-zinc-500 leading-tight max-w-xxs mx-auto italic">
                  *This device operates compliant ledger logs. Data inputs are utilized solely for user tracking metrics calculations.*
                </p>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Footer Navigation bar */}
      <div className="flex justify-between items-center gap-4 mt-auto pt-6 border-t border-zinc-900">
        {step > 1 ? (
          <button
            type="button"
            onClick={handleBack}
            className="px-5 py-2.5 rounded-lg border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-900/30 text-xs font-mono font-medium text-zinc-400 tracking-wider uppercase transition-all flex items-center gap-1.5"
          >
            <ChevronLeft className="w-3.5 h-3.5" /> Back
          </button>
        ) : (
          <div className="w-[10px]" /> /* spacer */
        )}

        <button
          type="button"
          onClick={handleNext}
          className="px-6 py-2.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-950 text-xs font-mono font-bold tracking-widest uppercase transition-all flex items-center gap-1 ml-auto"
        >
          {step === totalSteps ? 'Enable Tracking' : 'Proceed'} <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
