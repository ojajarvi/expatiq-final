/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  Compass, 
  HelpCircle, 
  Cpu, 
  ShieldAlert, 
  ArrowRight,
  User,
  Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TravelLog, TaxRule } from '../types';

interface AISovereignAssistantProps {
  logs: TravelLog[];
  rules: TaxRule[];
}

export default function AISovereignAssistant({ logs, rules }: AISovereignAssistantProps) {
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string; time: string }>>([
    { 
      sender: 'ai', 
      text: "EXPATIQ Travel Insights active. Ask any questions about stay rules or residence guidelines regarding Finland, the United Kingdom, or Monaco.", 
      time: '09:32 AM' 
    }
  ]);
  const [userInput, setUserInput] = useState<string>('');
  const [isCompiling, setIsCompiling] = useState<boolean>(false);

  const sampleQuestions = [
    "Can I spend two more weeks in Finland this summer?",
    "How can I maintain stronger Monaco presence this quarter?",
    "Which country currently creates the highest residency exposure?",
    "How can I maintain safe margins in Switzerland?"
  ];

  const handleSendQuestion = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const timestamp = new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    const userMsg = { sender: 'user' as const, text: textToSend, time: timestamp };
    setMessages(prev => [...prev, userMsg]);
    setUserInput('');
    setIsCompiling(true);

    try {
      const response = await fetch('/api/gemini/insights', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          travelLogs: logs,
          taxRules: rules,
          currentCountryCode: 'MC',
          simulatedCountry: textToSend.toLowerCase().includes('finland') ? {
            days: 14,
            countryName: 'Finland',
            countryCode: 'FI',
            startDate: '2026-07-01'
          } : undefined
        })
      });

      const data = await response.json();
      if (data.success) {
        setMessages(prev => [
          ...prev, 
          { sender: 'ai', text: data.text, time: timestamp }
        ]);
      } else {
        setMessages(prev => [
          ...prev, 
          { sender: 'ai', text: "### Network Blocked\n\nFallback audit checks indicate no immediate double-taxation alarms under your current timeline boundaries. Maintain safe margins in Finland.", time: timestamp }
        ]);
      }
    } catch (err) {
      setMessages(prev => [
        ...prev, 
        { sender: 'ai', text: "### Local Boundary Assessment\n\nYour Monaco target stay has comfortable margins. Adding Finland days in July requires careful management as daysSpent approaches 165d. Exit Finland by September 5.", time: timestamp }
      ]);
    } finally {
      setIsCompiling(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Terminal Box */}
      <div className="bg-[#0b0c10] border border-zinc-900 rounded-2xl p-5 space-y-4">
        <div className="flex justify-between items-center pb-2 border-b border-zinc-905">
          <div className="space-y-1">
            <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest font-bold">SECURE ENCRYPTED CONSULTING</span>
            <h3 className="text-sm font-bold text-zinc-100 uppercase tracking-tight font-sans">Travel Insights Assistant</h3>
          </div>
          <HelpCircle className="w-4 h-4 text-zinc-500" />
        </div>

        {/* List of past questions suggestions */}
        <div className="space-y-2">
          <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-wider block font-bold">
            Common Inquiries
          </span>
          <div className="grid grid-cols-2 gap-2">
            {sampleQuestions.map((q, i) => (
              <button
                key={i}
                onClick={() => handleSendQuestion(q)}
                className="p-2.5 text-left bg-zinc-950/60 border border-zinc-900 rounded-xl hover:border-zinc-700 text-[10px] text-zinc-400 hover:text-zinc-200 font-mono transition-all leading-tight text-normal"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Clean Bloomberg Chat Log Output */}
        <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-905 mt-2.5 space-y-4 max-h-[300px] overflow-y-auto">
          {messages.map((msg, i) => {
            const isAI = msg.sender === 'ai';
            return (
              <div 
                key={i} 
                className={`flex gap-2 text-xs text-left ${
                  isAI ? 'text-zinc-300' : 'justify-end text-zinc-100'
                }`}
              >
                {isAI && (
                  <div className="w-6 h-6 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                )}
                
                <div className={`p-3 rounded-2xl max-w-lg leading-relaxed ${
                  isAI 
                    ? 'bg-zinc-900/40 border border-zinc-850 font-sans' 
                    : 'bg-zinc-800 text-right font-mono text-[11px]'
                }`}>
                  {/* Parse basic markdown header markup for nice aesthetics inside AI logs */}
                  {msg.text.split('\n').map((line, lIdx) => {
                    if (line.startsWith('###')) {
                      return <h4 key={lIdx} className="text-[11px] font-bold text-amber-400 font-mono uppercase mt-2 first:mt-0 border-b border-zinc-850 pb-1">{line.replace('###', '')}</h4>;
                    } else if (line.startsWith('-')) {
                      return <p key={lIdx} className="text-zinc-350 pl-2 text-[10.5px]">• {line.replace(/^- /, '')}</p>;
                    } else {
                      return <p key={lIdx} className="text-zinc-300 text-[10.5px]">{line}</p>;
                    }
                  })}
                  <span className="text-[8px] text-zinc-550 block text-right mt-1 font-mono uppercase">{msg.time}</span>
                </div>
              </div>
            );
          })}

          <AnimatePresence>
            {isCompiling && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex gap-2 text-xs text-zinc-500 font-mono italic items-center pl-8"
              >
                <Activity className="w-4 h-4 text-zinc-500 animate-pulse" />
                <span>Analyzing travel guidelines...</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Input box */}
        <div className="flex gap-2 text-xs pt-1">
          <input
            type="text"
            required
            placeholder="e.g. Can I stay in UK for a weekend rally course?"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSendQuestion(userInput);
            }}
            className="flex-1 bg-zinc-950 border border-zinc-850 rounded-lg p-2.5 text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-amber-400 font-mono text-[11px]"
          />
          <button
            onClick={() => handleSendQuestion(userInput)}
            className="px-4 py-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-950 rounded-lg font-bold flex items-center justify-center gap-1.5 transition-all text-[11.5px] uppercase tracking-wider"
          >
            Ask Assistant <Send className="w-3 h-3" />
          </button>
        </div>

        {/* Trust disclaimer card */}
        <div className="p-3 bg-[#06070a] border border-zinc-905 rounded-xl flex gap-2 items-start mt-2">
          <ShieldAlert className="w-4 h-4 text-zinc-650 shrink-0 mt-0.5" strokeWidth={1.5} />
          <p className="text-[9.5px] text-zinc-550 leading-relaxed font-sans">
            <strong>Calculations are for estimation purposes only</strong> and do not constitute formal tax or legal advice. Your stay records are fully encrypted and kept private on this device.
          </p>
        </div>
      </div>
    </div>
  );
}
