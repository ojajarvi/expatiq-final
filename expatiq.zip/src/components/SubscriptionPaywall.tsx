/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Check, 
  Sparkles, 
  Crown, 
  Copy, 
  HeartHandshake, 
  Share2, 
  Flame, 
  Gift, 
  TrendingUp, 
  Star 
} from 'lucide-react';
import { motion } from 'motion/react';

interface SubscriptionPaywallProps {
  currentTier: 'Free' | 'Premium' | 'Concierge';
  onUpgrade: (tier: 'Free' | 'Premium' | 'Concierge') => void;
}

export default function SubscriptionPaywall({ currentTier, onUpgrade }: SubscriptionPaywallProps) {
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);
  const referralCode = "GLOBAL_VIP_256_HEK";

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const planTiers = [
    {
      id: 'Premium Monthly Access',
      tier: 'Premium' as const,
      price: '€9.99',
      interval: 'month',
      badge: 'Flexible',
      desc: 'Encrypted stay duration calculations and automated background presence tracking.',
      features: [
        'Unlimited background presence tracking',
        'Continuous geofencing border triggers',
        'Official monochrome PDF, CSV & Excel exports',
        'Dynamic residency limit countdown alerts',
        'Encrypted & private local database sync'
      ]
    },
    {
      id: 'Premium Yearly Access',
      tier: 'Premium' as const,
      price: '€99.99',
      interval: 'year',
      badge: 'Best Value',
      savings: '12 months + 2 free',
      desc: 'Meticulous 12-month travel logs assurance designed for wealthy international citizens.',
      features: [
        'Everything in Monthly Premium',
        'High integrity location triangulation support',
        'CPA & Accountant-ready reports stamp',
        'Cryptographic integrity verification check keys'
      ]
    }
  ];

  return (
    <div className="space-y-6">
      
      {/* 1. PAYWALL UPGRADE CONTAINER */}
      <div className="bg-[#0b0c10] border border-zinc-900 rounded-2xl p-5 space-y-4">
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <span className="text-[9px] font-mono text-amber-500 uppercase tracking-widest font-bold">PREMIUM RESIDENCY EXPANSION</span>
            <h3 className="text-sm font-extrabold text-zinc-100 uppercase tracking-tight">EXPATIQ Premium Membership</h3>
            <p className="text-[10.5px] text-zinc-550 font-serif italic">Encrypted location mapping to provide seamless long-term presence insights and compliance reports.</p>
          </div>
          <Crown className="w-5 h-5 text-amber-400 shrink-0" />
        </div>

        {/* Dynamic selector of Tiers */}
        <div className="space-y-4 pt-2">
          {planTiers.map((plan) => {
            const isActive = currentTier === 'Premium'; // Both plans activate Premium
            return (
              <div 
                key={plan.id}
                className={`p-4 rounded-xl border relative overflow-hidden transition-all text-left ${
                  plan.badge === 'Best Value' 
                    ? 'bg-[#100d07] border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.08)]' 
                    : 'bg-zinc-950 border-zinc-905 hover:border-zinc-850'
                }`}
              >
                {/* Visual badge top corner */}
                <div className="absolute top-3 right-3 flex items-center gap-1">
                  <span className={`text-[8.5px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                    plan.badge === 'Best Value' 
                      ? 'bg-amber-500 text-zinc-950'
                      : 'bg-zinc-900 text-zinc-400'
                  }`}>
                    {plan.badge}
                  </span>
                </div>

                <div className="space-y-2">
                  <div>
                    <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wide font-sans">{plan.id}</h4>
                    <p className="text-[10.5px] text-zinc-550 mt-0.5 max-w-xs leading-normal">{plan.desc}</p>
                  </div>

                  <div className="flex items-baseline gap-1 mt-1 border-b border-zinc-900 pb-2.5">
                    <span className="text-lg font-mono font-bold text-zinc-100">{plan.price}</span>
                    <span className="text-[10px] text-zinc-550">/ {plan.interval}</span>
                    {plan.savings && (
                      <span className="text-[9.5px] font-mono text-emerald-400 ml-3 font-bold">{plan.savings}</span>
                    )}
                  </div>

                  {/* Feature lists */}
                  <ul className="space-y-1.5 text-[9.5px] text-zinc-404 pt-1">
                    {plan.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex gap-2 items-start shrink-0">
                        <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                        <span className="leading-snug text-zinc-300">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA toggle button */}
                  <div className="pt-2">
                    <button
                      onClick={() => onUpgrade(plan.tier)}
                      className={`w-full py-2 rounded text-[10px] font-mono tracking-widest uppercase font-bold transition-all ${
                        plan.badge === 'Best Value'
                          ? 'bg-amber-500 hover:bg-amber-400 text-zinc-950'
                          : 'bg-zinc-900 hover:bg-zinc-850 text-zinc-200 border border-zinc-805'
                      }`}
                    >
                      {isActive ? 'Your Active Plan ✓' : `Subscribe to ${plan.tier} Tier`}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* RESTORE PURCHASES AND REVENUECAT STATUS BAR */}
        <div className="pt-3.5 border-t border-zinc-900 flex flex-col gap-2">
          <div className="flex justify-between items-center text-[10px] font-mono">
            <span className="text-zinc-550 uppercase">App Store Receipts</span>
            <button
              onClick={() => {
                setRestoreMessage('Contacting receipt server...');
                setTimeout(() => {
                  setRestoreMessage('Your Premium subscription layer has been successfully restored.');
                }, 1200);
              }}
              className="px-2.5 py-1 bg-zinc-950 hover:bg-zinc-900 border border-zinc-805 rounded uppercase font-bold text-[9px] text-zinc-300 transition-colors"
            >
              Restore Purchases
            </button>
          </div>

          {restoreMessage && (
            <div className="p-2.5 text-[9px] border border-amber-500/10 bg-amber-500/5 text-amber-400 font-mono rounded-lg">
              {restoreMessage}
            </div>
          )}

          <div className="p-2.5 bg-zinc-950 border border-zinc-905 rounded-lg flex justify-between items-center text-[9.5px] font-mono text-zinc-500">
            <span>Transaction Logs Sync</span>
            <span className="text-emerald-500 font-bold uppercase">SECURE_CACHE_ACTIVE</span>
          </div>
        </div>
      </div>
    </div>
  );
}
