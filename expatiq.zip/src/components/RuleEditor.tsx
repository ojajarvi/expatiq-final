/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings, ShieldAlert, Plus, Trash2, HelpCircle, Save, Check } from 'lucide-react';
import { TaxRule } from '../types';

interface RuleEditorProps {
  rules: TaxRule[];
  onAddRule: (rule: Omit<TaxRule, 'id'>) => void;
  onDeleteRule: (id: string) => void;
  onResetPresets: () => void;
}

export default function RuleEditor({ rules, onAddRule, onDeleteRule, onResetPresets }: RuleEditorProps) {
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [countryCode, setCountryCode] = useState<string>('CH');
  const [countryName, setCountryName] = useState<string>('Switzerland');
  const [maxDaysLimit, setMaxDaysLimit] = useState<number>(90);
  const [minDaysRequired, setMinDaysRequired] = useState<number>(0);
  const [warningThresholdDays, setWarningThresholdDays] = useState<number>(15);
  const [description, setDescription] = useState<string>('Lump-sum tax compliance buffer rule.');

  // Pre-configured custom country templates to load instantly
  const templates = [
    { code: 'CH', name: 'Switzerland', max: 90, min: 0, warn: 15, desc: 'Lump-sum tax compliance buffer rule.' },
    { code: 'ES', name: 'Spain', max: 183, min: 0, warn: 20, desc: 'Avoid accidental tax residency threshold.' },
    { code: 'PT', name: 'Portugal', max: 183, min: 0, warn: 20, desc: 'NHR status day tracking buffer limit.' },
    { code: 'SG', name: 'Singapore', max: 183, min: 0, warn: 20, desc: 'Accidental resident status tracker.' },
    { code: 'UK', name: 'United Kingdom', max: 90, min: 0, warn: 10, desc: 'Sufficient Ties Test strict threshold.' }
  ];

  const handleApplyTemplate = (tpl: typeof templates[0]) => {
    setCountryCode(tpl.code);
    setCountryName(tpl.name);
    setMaxDaysLimit(tpl.max);
    setMinDaysRequired(tpl.min);
    setWarningThresholdDays(tpl.warn);
    setDescription(tpl.desc);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddRule({
      countryCode: countryCode.toUpperCase(),
      countryName,
      maxDaysLimit,
      minDaysRequired: minDaysRequired > 0 ? minDaysRequired : undefined,
      warningThresholdDays,
      description
    });
    setShowAddForm(false);
  };

  return (
    <div className="bg-[#0d0e12] border border-zinc-800/80 rounded-xl p-5 font-sans space-y-5 text-zinc-100">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-sm font-semibold text-zinc-100 flex items-center gap-1.5 font-mono uppercase tracking-wider">
            <Settings className="w-4 h-4 text-zinc-300" /> Compliance Criteria
          </h2>
          <p className="text-[11px] text-zinc-500">Define sovereign stay limitations</p>
        </div>
        <button
          onClick={onResetPresets}
          className="text-[9.5px] font-mono tracking-wider text-zinc-500 hover:text-amber-400 border border-zinc-800 hover:border-amber-400/40 px-2 py-1 rounded"
        >
          Reset Presets
        </button>
      </div>

      {/* Rules Grid */}
      <div className="space-y-3">
        {rules.map((rule) => (
          <div key={rule.id} className="bg-zinc-900/40 border border-zinc-850 rounded-lg p-3.5 flex flex-col justify-between gap-2.5">
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-mono text-center px-1.5 py-0.5 rounded bg-zinc-800 font-bold tracking-wider">{rule.countryCode}</span>
                  <h4 className="text-xs font-semibold text-zinc-200">{rule.countryName}</h4>
                </div>
                <p className="text-[11px] text-zinc-400 leading-snug">{rule.description}</p>
              </div>
              <button
                onClick={() => onDeleteRule(rule.id)}
                className="text-zinc-600 hover:text-rose-400 transition-colors p-1"
                title="Delete Rule"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 border-t border-zinc-855 pt-3 text-[10.5px] font-mono">
              <div className="space-y-0.5">
                <span className="text-[8px] text-zinc-500">MAX ALLOWED</span>
                <div className="text-zinc-300 font-bold">{rule.maxDaysLimit} Days</div>
              </div>
              <div className="space-y-0.5">
                <span className="text-[8px] text-zinc-500">MIN REQUIRE</span>
                <div className="text-zinc-300 font-bold">{rule.minDaysRequired ? `${rule.minDaysRequired} Days` : 'N/A'}</div>
              </div>
              <div className="space-y-0.5 animate-pulse">
                <span className="text-[8px] text-zinc-500">WARN TRIGGER</span>
                <div className="text-amber-400 font-bold">-{rule.warningThresholdDays} Days</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Toggle Form to Add Custom State Rule */}
      {!showAddForm ? (
        <button
          onClick={() => setShowAddForm(true)}
          className="w-full py-2 border border-dashed border-zinc-800 hover:border-zinc-700/80 hover:bg-zinc-900/20 text-xs font-medium text-zinc-400 tracking-wide rounded-lg flex items-center justify-center gap-1.5 transition-all"
        >
          <Plus className="w-3.5 h-3.5" /> Define Custom Country Guideline
        </button>
      ) : (
        <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-850 space-y-4">
          <div className="text-[10px] font-mono uppercase tracking-wider text-amber-400">New Residency Stay Guideline</div>
          
          {/* Presets load area */}
          <div className="flex flex-wrap gap-1.5 p-2 bg-zinc-900/50 rounded-md border border-zinc-900">
            <span className="text-[9px] font-mono text-zinc-500 my-auto mr-1 block">Quick Templates:</span>
            {templates.map(tpl => (
              <button
                key={tpl.code}
                onClick={() => handleApplyTemplate(tpl)}
                className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
                type="button"
              >
                +{tpl.code}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[9px] uppercase tracking-wider text-zinc-500 mb-1">Country ISO Code</label>
                <input
                  type="text"
                  maxLength={2}
                  required
                  value={countryCode}
                  onChange={(e) => setCountryCode(e.target.value.toUpperCase())}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-200 focus:outline-none focus:border-amber-400 font-mono"
                  placeholder="e.g. PT"
                />
              </div>
              <div>
                <label className="block text-[9px] uppercase tracking-wider text-zinc-500 mb-1">Country Name</label>
                <input
                  type="text"
                  required
                  value={countryName}
                  onChange={(e) => setCountryName(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-200 focus:outline-none focus:border-amber-400"
                  placeholder="e.g. Portugal"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              <div>
                <label className="block text-[9px] uppercase tracking-wider text-zinc-500 mb-1">Max Days</label>
                <input
                  type="number"
                  required
                  value={maxDaysLimit}
                  onChange={(e) => setMaxDaysLimit(parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-200 focus:outline-none text-center font-mono"
                />
              </div>
              <div>
                <label className="block text-[9px] uppercase tracking-wider text-zinc-500 mb-1">Min Stay (Req)</label>
                <input
                  type="number"
                  value={minDaysRequired}
                  onChange={(e) => setMinDaysRequired(parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-200 focus:outline-none text-center font-mono"
                  placeholder="None"
                />
              </div>
              <div>
                <label className="block text-[9px] uppercase tracking-wider text-zinc-500 mb-1">Warning (Days)</label>
                <input
                  type="number"
                  required
                  value={warningThresholdDays}
                  onChange={(e) => setWarningThresholdDays(parseInt(e.target.value) || 0)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-200 focus:outline-none text-center font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-[9px] uppercase tracking-wider text-zinc-500 mb-1">Description Reference</label>
              <input
                type="text"
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-200 focus:outline-none"
                placeholder="Tax rule background detail..."
              />
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="flex-1 py-2 text-xs font-mono tracking-wider uppercase border border-zinc-800 text-zinc-400 hover:bg-zinc-900 rounded"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2 text-xs font-mono tracking-wider uppercase bg-amber-500 text-[#09090b] font-bold hover:bg-amber-400 rounded flex items-center justify-center gap-1"
              >
                <Save className="w-3.5 h-3.5" /> Save Rule
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
