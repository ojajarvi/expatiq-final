/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { ShieldCheck, Fingerprint, Keyboard, ArrowRight, Eye, EyeOff } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface BiometricCoverProps {
  onUnlock: () => void;
}

export default function BiometricCover({ onUnlock }: BiometricCoverProps) {
  const [passcode, setPasscode] = useState<string>('');
  const [showFaceID, setShowFaceID] = useState<boolean>(true);
  const [lockStatus, setLockStatus] = useState<'locked' | 'authenticating' | 'failed' | 'success'>('locked');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [showNumbers, setShowNumbers] = useState<boolean>(false);

  const correctPasscode = '2026'; // Custom VIP passcode

  const handleKeyPress = (num: string) => {
    if (passcode.length < 4) {
      const newPass = passcode + num;
      setPasscode(newPass);
      if (newPass === correctPasscode) {
        setLockStatus('success');
        setTimeout(() => onUnlock(), 600);
      } else if (newPass.length === 4) {
        setLockStatus('failed');
        setTimeout(() => {
          setPasscode('');
          setLockStatus('locked');
          setErrorMsg('Invalid VIP Code. Try "2026"');
        }, 1200);
      }
    }
  };

  const clearPasscode = () => {
    setPasscode('');
    setErrorMsg('');
  };

  const triggerFaceIDSim = () => {
    setLockStatus('authenticating');
    setTimeout(() => {
      setLockStatus('success');
      setTimeout(() => onUnlock(), 800);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-[#07080a] text-zinc-100 flex flex-col justify-between p-8 z-50 font-sans">
      {/* Top Bar telemetry info */}
      <div className="flex justify-between items-center text-[10px] uppercase tracking-widest text-zinc-500 font-mono">
        <div className="flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          SECURE CHANNEL 256-BIT
        </div>
        <div>TIME UTC: 2026-05-23</div>
      </div>

      {/* Main Authentic FaceID Ring */}
      <div className="flex flex-col items-center justify-center my-auto space-y-8">
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-amber-500/10 blur-xl"></div>
          
          <motion.div 
            animate={lockStatus === 'authenticating' ? { rotate: 360 } : {}}
            transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
            className={`w-32 h-32 rounded-full border-2 flex items-center justify-center relative transition-all duration-500 ${
              lockStatus === 'success' ? 'border-emerald-500 bg-emerald-500/10' :
              lockStatus === 'failed' ? 'border-rose-500 bg-rose-500/10 animate-bounce' :
              lockStatus === 'authenticating' ? 'border-amber-400 border-t-transparent' : 'border-zinc-800'
            }`}
          >
            {lockStatus === 'success' ? (
              <ShieldCheck className="w-12 h-12 text-emerald-400" />
            ) : lockStatus === 'failed' ? (
              <Fingerprint className="w-12 h-12 text-rose-400" />
            ) : (
              <Fingerprint 
                className={`w-12 h-12 transition-colors cursor-pointer ${
                  lockStatus === 'authenticating' ? 'text-amber-400' : 'text-zinc-400 hover:text-amber-400'
                }`}
                onClick={triggerFaceIDSim}
              />
            )}
          </motion.div>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-xl font-medium tracking-tight bg-gradient-to-r from-zinc-100 to-zinc-400 bg-clip-text text-transparent">
            {lockStatus === 'authenticating' ? 'Scanning Biometrics...' : 
             lockStatus === 'success' ? 'Access Granted' : 'EXPATIQ'}
          </h1>
          <p className="text-xs text-zinc-400 max-w-xs mx-auto">
            Global residency intelligence and travel documentation ledger. High-net-worth identity shield active.
          </p>
        </div>

        {/* Lock mechanism switch */}
        {!showNumbers ? (
          <div className="flex flex-col items-center space-y-3 pt-4">
            <button 
              onClick={triggerFaceIDSim}
              className="px-6 py-2.5 rounded-full bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-xs font-medium tracking-wide transition-all shadow-lg text-emerald-400 uppercase"
            >
              Simulate Face ID Unlock
            </button>
            <button 
              onClick={() => setShowNumbers(true)}
              className="text-xs text-zinc-500 hover:text-zinc-300 transition-colors flex items-center gap-1"
            >
              <Keyboard className="w-3.5 h-3.5" /> Or Enter VIP Passcode
            </button>
          </div>
        ) : (
          <div className="w-full max-w-xs space-y-6">
            {/* Visual Passcode indicators */}
            <div className="flex justify-center items-center gap-4">
              {[0, 1, 2, 3].map((idx) => (
                <div 
                  key={idx}
                  className={`w-3.5 h-3.5 rounded-full border transition-all duration-300 ${
                    passcode.length > idx 
                      ? 'bg-amber-400 border-amber-400 scale-110' 
                      : 'border-zinc-700 bg-transparent'
                  }`}
                />
              ))}
            </div>

            {errorMsg && (
              <div className="text-center text-[11px] text-rose-400 font-medium font-mono">
                {errorMsg}
              </div>
            )}

            {/* Custom high-end pin pad */}
            <div className="grid grid-cols-3 gap-y-3 gap-x-6 text-center">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                <button
                  key={num}
                  onClick={() => handleKeyPress(num)}
                  className="w-14 h-14 rounded-full bg-zinc-900/60 border border-zinc-800/80 mx-auto flex items-center justify-center text-lg font-mono text-zinc-300 hover:bg-zinc-800 active:scale-95 transition-all"
                >
                  {num}
                </button>
              ))}
              <button
                onClick={clearPasscode}
                className="text-[10px] uppercase tracking-widest text-zinc-500 hover:text-rose-400 transition-colors font-mono my-auto"
              >
                Clear
              </button>
              <button
                onClick={() => handleKeyPress('0')}
                className="w-14 h-14 rounded-full bg-zinc-900/60 border border-zinc-800/80 mx-auto flex items-center justify-center text-lg font-mono text-zinc-300 hover:bg-zinc-800 active:scale-95 transition-all"
              >
                0
              </button>
              <button
                onClick={() => setShowNumbers(false)}
                className="text-[10px] uppercase tracking-widest text-zinc-500 hover:text-amber-400 transition-colors font-mono my-auto"
              >
                FaceID
              </button>
            </div>
            <div className="text-center text-[10px] text-zinc-600 font-mono">
              VIP ACCESS PASSCODE: <span className="text-zinc-500 font-medium">2026</span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom disclaimer footer */}
      <div className="text-center text-[9px] text-zinc-500 space-y-1">
        <div className="font-mono uppercase tracking-widest text-[#cca568]">EXPATIQ SECURED ACCESS LEVEL 3</div>
        <div>All inputs logged locally with optional military-grade encryption.</div>
      </div>
    </div>
  );
}
